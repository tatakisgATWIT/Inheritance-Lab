/* @formatter:off
 *
 * Dave Rosenberg
 * Comp 1050 - Computer Science II
 * Demonstration: range of values for each numeric (primitive) data type
 * Spring, 2023
 *
 * Usage restrictions:
 *
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 *
 * Further, you may not post (including in a public repository such as on github)
 * nor otherwise share this code with anyone other than current students in my
 * sections of this course. Violation of these usage restrictions will be considered
 * a violation of the Wentworth Institute of Technology Academic Honesty Policy.
 *
 * Do not remove this notice.
 *
 * @formatter:on
 */


package edu.wit.scds.dmr.tests ;

/**
 * Display the range of values for each of the integer types
 *
 * @author Dave Rosenberg
 *
 * @version 1.0.0 2021-08-27 Initial implementation
 */
public class ShowRanges
    {

    /**
     * Use reflection to retrieve the MIN_ and MAX_VALUEs for each integer type
     *
     * @param args
     *     -unused-
     *
     * @throws Throwable
     *     anything the JVM may cough up
     */
    public static void main( final String[] args ) throws Throwable
        {
        final String[] integerTypes = { "Byte", "Short", "Character", "Integer", "Long" } ;

        try
            {

            for ( final String className : integerTypes )
                {
                final Class<?> theClass = Class.forName( "java.lang." + className ) ;
                System.out.printf( "%9s: %,26d .. %,d%n",
                                   className,
                                   theClass.getDeclaredField( "MIN_VALUE" ).getLong( null ),
                                   theClass.getDeclaredField( "MAX_VALUE" ).getLong( null ) ) ;
                }

            }
        catch ( IllegalArgumentException |
                IllegalAccessException |
                NoSuchFieldException |
                SecurityException |
                ClassNotFoundException e )
            {
            // serious problem if any of these occur!
            e.printStackTrace() ;

            throw e ;   // re-throw it
            }

        }   // end main()

    }	// end class ShowRanges