/* @formatter:off
 *
 * Dave Rosenberg
 * Comp 1050 - Computer Science II
 * Lab: Inheritance
 * Spring, 2023
 *
 * Usage restrictions:
 *
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 *
 * Further, you may not post (including in a public repository such as on github)
 * nor otherwise share this code with anyone other than current students in my
 * sections of this course. Violation of these usage restrictions will be considered
 * a violation of the Wentworth Institute of Technology Academic Honesty Policy.
 *
 * Do not remove this notice.
 *
 * @formatter:on
 */


package edu.wit.scds.dmr.tests ;

import static edu.wit.scds.dmr.testing.framework.Reflection.getLongField ;
import static edu.wit.scds.dmr.testing.framework.Reflection.instantiate ;
import static edu.wit.scds.dmr.testing.framework.Reflection.invoke ;
import static edu.wit.scds.dmr.testing.framework.Reflection.setLongField ;
import static edu.wit.scds.dmr.testing.framework.TestData.itemToString ;
import static org.junit.jupiter.api.Assertions.assertAll ;
import static org.junit.jupiter.api.Assertions.assertEquals ;
import static org.junit.jupiter.api.Assertions.assertFalse ;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively ;
import static org.junit.jupiter.api.Assertions.assertTrue ;
import static org.junit.jupiter.api.Assertions.fail ;

import edu.wit.scds.dmr.testing.framework.JUnitTestingBase ;
import edu.wit.scds.dmr.testing.framework.TestingException ;

import org.junit.jupiter.api.Disabled ;
import org.junit.jupiter.api.DisplayName ;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation ;
import org.junit.jupiter.api.Order ;
import org.junit.jupiter.api.Test ;
import org.junit.jupiter.api.TestInstance ;
import org.junit.jupiter.api.TestInstance.Lifecycle ;
import org.junit.jupiter.api.TestMethodOrder ;

import java.util.Random ;


/**
 * JUnit tests for the Inheritance (MyLong, MyInteger, MyCharacter, MyByte) classes. All methods are
 * tested.
 *
 * @author David M Rosenberg
 *
 * @version 1.0.0 2021-08-08 derived from MyLongDMRTests and MyIntegerDMRTests
 * @version 1.1.0 2022-04-09 fix fluent test for correct instance returned
 * @version 1.2.0 2022-04-22
 *     <ul>
 *     <li>remove stray argument to {@code String.format()} in {@code startTestHeaderMessage()}
 *     <li>correct exception class tests in {@code isDivisionByZero()} and
 *     {@code isRangeViolation()}
 *     <li>rename constructor test methods for consistency with other test method names wrt
 *     parameters
 *     <li>add missing tests:
 *     <ul>
 *     <li>{@code setLong(MyLong)}
 *     <li>{@code isInRange(long)} - pending
 *     <li>{@code toInRange(long)} - pending
 *     </ul>
 *     </li>
 *     <li>constrain initial context value to within the valid range for the class under test to
 *     eliminate separate tests for {@code MyByte} and {@code MyCharacter}
 *     <li>miscellaneous fixes to tests:
 *     <ul>
 *     <li>{@code isEven()}
 *     <li>{@code isOdd()}
 *     <li>{@code toString()}
 *     </ul>
 *     </li>
 *     <li>renamed {@code limitedValue()} to {@code constrainedValue()}
 *     </ul>
 * @version 1.3.0 2023-03-15
 *     <ul>
 *     <li>add missing tests:
 *     <ul>
 *     <li>{@code isInRange(long)} and {@code toInRange(long)}
 *     </ul>
 *     </li>
 *     <li>add missing tests - pending:
 *     <ul>
 *     <li>declaration of {@code value} as {@code protected long} field in {@code MyLong} only
 *     <li>LOWER/UPPER_LIMIT constants
 *     <li>for all methods that take argument(s) of type {@code MyLong}, test with all class types
 *     </ul>
 *     </li>
 *     <li>fix {@code equals(long)} test to only use constrained context value
 *     <li>finish incomplete Javadoc comment blocks
 *     </ul>
 */
@DisplayName( "MyXxxx" )     // will be overridden by actual test class
@TestInstance( Lifecycle.PER_CLASS )
@TestMethodOrder( OrderAnnotation.class )
abstract class MyXxxxDMRTestingBase extends JUnitTestingBase
    {
    /*
     * test constants, counters and labels
     */
    /** name of the test class' package */
    protected final static String TEST_PACKAGE_NAME = "edu.wit.scds.cs2.lab03" ;
    /** name of the test class */
    protected static String TEST_CLASS_NAME ;

    /** MyLong class */
    protected static Class<?> MYLONG_CLASS ;


    // utility constants - for testing
    /** smallest value that can be stored in the test class */
    protected static long LOWER_LIMIT ;
    /** largest value that can be stored in the test class */
    protected static long UPPER_LIMIT ;
    /** default for {@code value} in the test class */
    protected final static long VALUE_DEFAULT = 0 ;


    // utility constants - exception handling
    /** class of Throwable expected for value out-of-range conditions */
    protected final static Class<?> OUT_OF_RANGE_EXCEPTION = IllegalArgumentException.class ;
    /** simple name of {@code OUT_OF_RANGE_EXCEPTION} */
    protected final static String OUT_OF_RANGE_EXCEPTION_NAME = OUT_OF_RANGE_EXCEPTION.getSimpleName() ;
    /** expected message with {@code OUT_OF_RANGE_EXCEPTION} */
    protected final static String OUT_OF_RANGE_EXCEPTION_MESSAGE = "value is out of range" ;
    /** full description of {@code OUT_OF_RANGE_EXCEPTION} */
    protected final static String OUT_OF_RANGE_EXCEPTION_DESCRIPTION = OUT_OF_RANGE_EXCEPTION_NAME +
                                                                       ": " +
                                                                       OUT_OF_RANGE_EXCEPTION_MESSAGE ;

    /** class of Throwable expected for division by zero (0) conditions */
    protected final static Class<?> DIVISION_BY_ZERO_EXCEPTION = IllegalArgumentException.class ;
    /** simple name of {@code DIVISION_BY_ZERO_EXCEPTION} */
    protected final static String DIVISION_BY_ZERO_EXCEPTION_NAME = DIVISION_BY_ZERO_EXCEPTION.getSimpleName() ;
    /** expected message with {@code DIVISION_BY_ZERO_EXCEPTION} */
    protected final static String DIVISION_BY_ZERO_EXCEPTION_MESSAGE = "divisor is 0" ;
    /** full description of {@code DIVISION_BY_ZERO_EXCEPTION} */
    protected final static String DIVISION_BY_ZERO_EXCEPTION_DESCRIPTION = DIVISION_BY_ZERO_EXCEPTION_NAME +
                                                                           ": " +
                                                                           DIVISION_BY_ZERO_EXCEPTION_MESSAGE ;


    // ----------


    /**
     * constructor
     *
     * @param valueTypeName
     *     type of class under test - the limiting range of {@code this.value}
     *
     * @throws Throwable
     *     anything thrown by reflection
     */
    protected MyXxxxDMRTestingBase( final String valueTypeName ) throws Throwable
        {
        super( TEST_PACKAGE_NAME, TEST_CLASS_NAME = "My" + valueTypeName ) ;

        MYLONG_CLASS = super.testSuperClass == Object.class
            ? super.testClass
            : super.testSuperClass ;

        // retrieve the range of values for this integer type
        final Class<?> valueClass = Class.forName( "java.lang." + valueTypeName ) ;
        LOWER_LIMIT = valueClass.getDeclaredField( "MIN_VALUE" ).getLong( null ) ;
        UPPER_LIMIT = valueClass.getDeclaredField( "MAX_VALUE" ).getLong( null ) ;

        }   // end constructor

    // ----------


    /**
     * Utility method to start no-arg constructor test
     *
     * @param expectedValue
     *     expected state of {@code value} data field
     */
    protected void startTestConstructor( final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( "%n[%,d, %,d] Testing: new %s()%n" + "\texpect: context.value: %,d%n",
                  super.currentTestGroup,
                  super.currentTestsAttempted,
                  super.testClassSimpleName,
                  expectedValue ) ;

        }   // end startTestConstructor()


    /**
     * Utility method to exercise no-arg constructor
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything the constructor may throw
     */
    protected void doTestConstructor()
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        final long initialValue = VALUE_DEFAULT ;

        startTestConstructor( initialValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance
                final Object contextInstance = instantiate( super.testClass ) ;

                // verify context instance state
                verifyState( contextInstance, initialValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown ) ;
            }

        reportEndOfTest() ;

        }   // end doTestConstructor()


    /**
     * Test method for no-arg constructor
     */
    @Test
    @DisplayName( "no-arg Constructor" )
    @Order( 20100 )
    protected void testConstructor()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () ->
            {
            super.lastTestInGroupIsRunning = true ;

            doTestConstructor() ; // expected state
            } ) ;       // end assertAll

        }   // end testConstructor()


    // ----------


    /**
     * Utility method to start 1-arg (long) constructor test
     *
     * @param initialValue
     *     value to new MyXxxx( initialValue )
     */
    protected void startTestConstructorLong( final long initialValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        if ( willFit( initialValue ) )
            {
            writeLog( "%snew %s( %,d )%n" + "\texpect: context.value: %<,d%n",
                      startTestHeaderMessage(),
                      super.testClassSimpleName,
                      initialValue ) ;
            }
        else
            {
            writeLog( "%snew %s( %,d )%n" + "\texpect: thrown: %s%n",
                      startTestHeaderMessage(),
                      super.testClassSimpleName,
                      initialValue,
                      OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ;
            }

        }   // end startTestConstructorLong()


    /**
     * Utility method to exercise new MyXxxx() with 1 long argument
     *
     * @param initialValue
     *     value to new MyXxxx( initialValue )
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything the constructor may throw
     */
    protected void doTestConstructorLong( final long initialValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        startTestConstructorLong( initialValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance
                final Object contextInstance = instantiate( super.testClass,
                                                            new Class<?>[]
                                                            { long.class },
                                                            initialValue ) ;

                // verify context instance state
                verifyState( contextInstance, initialValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, initialValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestConstructorLong()


    /**
     * Test method for 1-arg (long) constructor
     */
    @Test
    @DisplayName( "1-arg (long) Constructor" )
    @Order( 20200 )
    protected void testConstructorLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestConstructorLong( 0L ),
                   () -> doTestConstructorLong( 42L ),
                   () -> doTestConstructorLong( UPPER_LIMIT ),
                   () -> doTestConstructorLong( LOWER_LIMIT ),
                   () -> doTestConstructorLong( UPPER_LIMIT + 1L ),
                   () -> doTestConstructorLong( LOWER_LIMIT - 1L ),
                   () -> doTestConstructorLong( UPPER_LIMIT - 1L ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestConstructorLong( LOWER_LIMIT + 1L ) ;
                       } ) ;    // end assertAll

        }   // end testConstructorLong()


    // ----------


    /**
     * Utility method to start 1-arg 'cloning' constructor test
     *
     * @param argumentValue
     *     value for the argument instance
     * @param expectedValue
     *     the expected value for a successfully instantiated object
     */
    protected void startTestConstructorMyLong( final Long argumentValue,
                                               final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        if ( ( argumentValue == null ) || willFit( argumentValue ) )                          // URHERE
            {
            writeLog( """
                      %n%snew %s( %s )%n\
                      \tsetup: argument%s%n\
                      \texpect: context.value: %,d%n\
                      %s""",
                      startTestHeaderMessage(),
                      super.testClassSimpleName,
                      ( argumentValue == null
                          ? "null"
                          : String.format( "MyLong( %,d )", argumentValue ) ),
                      ( argumentValue == null
                          ? ": null"
                          : String.format( ".value: %,d", argumentValue ) ),
                      expectedValue,
                      ( argumentValue == null
                          ? ""
                          : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ) ) ;
            }
        else     // we have an argumentValue that will not fit
            {
            writeLog( """
                      %snew %s( MyLong( %,d ) )%n\
                      \tsetup: argument.value: %,d%n\
                      \texpect: argument.value: %,d%n\
                      \texpect: thrown: %s%n""",
                      startTestHeaderMessage(),
                      super.testClassSimpleName,
                      argumentValue,
                      argumentValue,
                      argumentValue,
                      OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ;
            }

        }   // end startTestConstructorMyLong()


    /**
     * Utility method to exercise new MyXxxx(MyLong)
     *
     * @param argumentValue
     *     value for the argument instance
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything the constructor may throw
     */
    protected void doTestConstructorMyLong( final Long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        final long expectedValue = ( argumentValue == null
            ? VALUE_DEFAULT
            : (long) argumentValue ) ;

        startTestConstructorMyLong( argumentValue, expectedValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // construct the argument
                final Object argumentInstance ;

                if ( argumentValue == null )
                    {
                    argumentInstance = null ;
                    }
                else
                    {
                    argumentInstance = createMyLongInstance( expectedValue ) ;
                    }

                // instantiate the context instance and set the initial state
                Throwable savedThrown = null ;

                try
                    {
                    final Object contextInstance = instantiate( super.testClass,
                                                                new Class<?>[]
                                                                { MYLONG_CLASS },
                                                                argumentInstance ) ;

                    // verify context instance state
                    verifyState( contextInstance, expectedValue ) ;
                    }
                catch ( final Throwable caught )
                    {
                    savedThrown = caught ;
                    }

                // verify argument instance state - must be unchanged
                if ( argumentInstance != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", expectedValue ) ;
                    }

                if ( savedThrown != null )
                    {
                    throw savedThrown ;   // re-throw it
                    }

                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, argumentValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestConstructorMyLong()


    /**
     * Test method for 1-arg 'cloning' constructor
     */
    @Test
    @DisplayName( "1-arg 'cloning' Constructor" )
    @Order( 20300 )
    protected void testConstructorMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestConstructorMyLong( 0L ),
                   () -> doTestConstructorMyLong( 42L ),
                   () -> doTestConstructorMyLong( UPPER_LIMIT ),
                   () -> doTestConstructorMyLong( LOWER_LIMIT ),
                   () -> doTestConstructorMyLong( UPPER_LIMIT + 1L ),
                   () -> doTestConstructorMyLong( LOWER_LIMIT - 1L ),
                   () -> doTestConstructorMyLong( UPPER_LIMIT - 1L ),
                   () -> doTestConstructorMyLong( LOWER_LIMIT + 1L ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestConstructorMyLong( null ) ;
                       } ) ;    // end assertAll

        }   // end testConstructorMyLong()


    // ----------


    /**
     * Utility method to start class structure test
     */
    protected void startTestClassStructure()    // DMR FUTURE
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %sclass %s structure%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName ) ;

        }   // end startTestClassStructure()


    /**
     * Utility method to test class structure
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isInRange(long) may throw
     */
    protected void doTestClassStructure()       // DMR FUTURE
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        startTestClassStructure() ;

//        try
//            {
//            assertTimeoutPreemptively( super.testTimeLimit, () ->
//                {
//                // instantiate the context instance and set the initial state
//                final Object contextInstance = createInstance( VALUE_DEFAULT ) ;
//
//                // ensure only one data field - protected long value - in MyLong
////                final Field[] fields = 
//                
//                } ) ;
//            }
//        catch ( final Throwable thrown )
//            {
//            commonExceptionHandler( thrown ) ;
//            }

        reportEndOfTest() ;

        }   // end doTestClassStructure()


    /**
     * Test method for structure test
     */
    @Test
    @DisplayName( "Class Structure" )
    @Order( 10100 )
    @Disabled
    protected void testClassStructure()         // DMR FUTURE
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll(
                  // () -> doTestClassStructure(),
                  () ->
                      {
                      super.lastTestInGroupIsRunning = true ;

                      doTestClassStructure() ;
                      } ) ;   // end assertAll

        }   // end testClassStructure()


    // ----------


    /**
     * Utility method to start isInRange(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param testValue
     *     value to test for in-range-ness
     */
    protected void startTestIsInRange( final long contextValue,
                                       final long testValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).isInRange( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  testValue,
                  contextValue,
                  willFit( testValue ) ) ;

        }   // end startTestIsInRange()


    /**
     * Utility method to exercise isInRange(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param testValue
     *     value to test for in-range-ness
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isInRange(long) may throw
     */
    protected void doTestIsInRange( final long contextValue,
                                    final long testValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestIsInRange( constrainedContextValue, testValue ) ;

        try
            {
            final boolean expectedResult = willFit( testValue ) ;
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,
                                                                 contextInstance,
                                                                 "isInRange",
                                                                 new Class<?>[]
                                                                 { long.class },
                                                                 testValue ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;


                // verify context instance state is unchanged
                verifyState( contextInstance, "verify", "context", constrainedContextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, testValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsInRange()


    /**
     * Test method for isInRange(long)
     */
    @Test
    @DisplayName( "isInRange(long)" )
    @Order( 15100 )
    protected void testIsInRange()
        {
        // we'll randomly assign context values - they won't be changed by isInRange()
        Random random = new Random() ;
        final int CONTEXT_VALUE_UPPER_BOUND = 37 ;
        final long MIDPOINT = ( ( LOWER_LIMIT + 1 ) / 2 ) + ( UPPER_LIMIT / 2 ) ;

        super.lastTestInGroupIsRunning = false ;

        assertAll( // always true
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), 0L ),
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), LOWER_LIMIT ),
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         LOWER_LIMIT + 13 ),
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), MIDPOINT ),
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         UPPER_LIMIT - 17 ),
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), UPPER_LIMIT ),

                  // false except for MyLong
                  () -> doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         LOWER_LIMIT - 1 ),
                  () ->
                      {
                      super.lastTestInGroupIsRunning = true ;

                      doTestIsInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                       UPPER_LIMIT + 1 ) ;
                      } ) ;   // end assertAll

        }   // end testIsInRange()


    // ----------


    /**
     * Utility method to start toInRange(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param testValue
     *     value to ensure is in-range
     */
    protected void startTestToInRange( final long contextValue,
                                       final long testValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).toInRange( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: returned: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  testValue,
                  contextValue,
                  constrainValue( testValue ) ) ;

        }   // end startTestToInRange()


    /**
     * Utility method to exercise toInRange(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param testValue
     *     value to ensure is in-range
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything toInRange(long) may throw
     */
    protected void doTestToInRange( final long contextValue,
                                    final long testValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestToInRange( constrainedContextValue, testValue ) ;

        try
            {
            final long expectedResult = constrainValue( testValue ) ;
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final long returnedResult = (long) invoke( super.testClass,
                                                           contextInstance,
                                                           "toInRange",
                                                           new Class<?>[]
                                                           { long.class },
                                                           testValue ) ;

                // display the result
                writeLog( "\tactual: returned: %,d%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;


                // verify context instance state is unchanged
                verifyState( contextInstance, "verify", "context", constrainedContextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, testValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestToInRange()


    /**
     * Test method for toInRange(long)
     */
    @Test
    @DisplayName( "toInRange(long)" )
    @Order( 15200 )
    protected void testToInRange()
        {
        // we'll randomly assign context values - they won't be changed by toInRange()
        Random random = new Random() ;
        final int CONTEXT_VALUE_UPPER_BOUND = 37 ;
        final long MIDPOINT = ( ( LOWER_LIMIT + 1 ) / 2 ) + ( UPPER_LIMIT / 2 ) ;

        super.lastTestInGroupIsRunning = false ;

        assertAll( // always in-range
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), 0L ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), LOWER_LIMIT ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         LOWER_LIMIT + 13 ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), MIDPOINT ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         UPPER_LIMIT - 17 ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ), UPPER_LIMIT ),

                  // will be constrained except for MyLong
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         LOWER_LIMIT - 1 ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         Long.MIN_VALUE ),
                  () -> doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                         Long.MAX_VALUE ),
                  () ->
                      {
                      super.lastTestInGroupIsRunning = true ;

                      doTestToInRange( random.nextInt( CONTEXT_VALUE_UPPER_BOUND ),
                                       UPPER_LIMIT + 1 ) ;
                      } ) ;   // end assertAll

        }   // end testToInRange()


    // ----------


    /**
     * Utility method to start getValue() test
     *
     * @param contextValue
     *     value for value
     * @param expectedValue
     *     returned value
     */
    protected void startTestGetValue( final long contextValue,
                                      final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).getValue()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: returned: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  expectedValue ) ;

        }   // end startTestGetValue()


    /**
     * Utility method to exercise getValue()
     *
     * @param contextValue
     *     value for value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything valueOf() may throw
     */
    protected void doTestGetValue( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final long expectedValue = constrainValue( contextValue ) ;

        startTestGetValue( constrainedContextValue, expectedValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final long returnedValue = (long) invoke( super.testClass,
                                                          contextInstance,
                                                          "getValue" ) ;


                // display the result
                writeLog( "\tactual: returned: %,d%n", returnedValue ) ;

                // make sure we have the expected value
                assertEquals( expectedValue, returnedValue, "verify return value" ) ;


                // make sure the state is unchanged
                verifyState( contextInstance, "verify", "context", expectedValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestGetValue()


    /**
     * Test method for getValue()
     */
    @Test
    @DisplayName( "getValue()" )
    @Order( 30100 )
    protected void testGetValue()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestGetValue( 0L ),
                   () -> doTestGetValue( 12_345L ),
                   () -> doTestGetValue( -12_345L ),
                   () -> doTestGetValue( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestGetValue( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testGetValue()


    // ----------


    /**
     * Utility method to start setValue(long) test
     *
     * @param contextValue
     *     initial value for value
     * @param newValue
     *     replacement value for value
     */
    protected void startTestSetValueLong( final long contextValue,
                                          final long newValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        if ( willFit( newValue ) )
            {
            writeLog( """
                      %s%s( %,d ).setValue( %,d )%n\
                      \tsetup: context.value: %,d%n\
                      \texpect: context.value: %,d%n""",
                      startTestHeaderMessage(),
                      super.testClassSimpleName,
                      contextValue,
                      newValue,
                      contextValue,
                      newValue ) ;
            }
        else
            {
            writeLog( """
                      %s%s( %,d ).setValue( %,d )%n\
                      \tsetup: context.value: %,d%n\
                      \texpect: thrown: %s%n""",
                      startTestHeaderMessage(),
                      super.testClassSimpleName,
                      contextValue,
                      newValue,
                      contextValue,
                      OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ;
            }

//           // display message describing this test            // IN_PROCESS
//           writeLog( "%s%s( %,d ).setValue( %,d )%n" +
//                           "\tsetup: context.value: %,d%n" +
//                           "\texpect: context.value: %,d%n",
//                     startTestHeaderMessage(),
//                     super.testClassSimpleName,
//                     initialValue,
//                     newValue,
//                     initialValue,
//                     newValue ) ;

        }   // end startTestSetValueLong()


    /**
     * Utility method to exercise setValue(long)
     *
     * @param contextValue
     *     initial value for value
     * @param newValue
     *     replacement value for value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything setValue() may throw
     */
    protected void doTestSetValueLong( final long contextValue,
                                       final long newValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestSetValueLong( constrainedContextValue, newValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final Object returnedInstance = invoke( super.testClass,
                                                        contextInstance,
                                                        "setValue",
                                                        new Class<?>[]
                                                        { long.class },
                                                        newValue ) ;

                // verify context instance state and fluent reference returned
                verifyState( contextInstance, newValue, returnedInstance ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, newValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestSetValueLong()


    /**
     * Test method for setValue(long)
     */
    @Test
    @DisplayName( "setValue(long)" )
    @Order( 40100 )
    protected void testSetValueLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestSetValueLong( 101L, 5L ),
                   () -> doTestSetValueLong( 123L, -17L ),
                   () -> doTestSetValueLong( -321L, -17L ),
                   () -> doTestSetValueLong( 25L, 25L ),
                   () -> doTestSetValueLong( -34L, 0L ),
                   () -> doTestSetValueLong( UPPER_LIMIT, 25L ),
                   () -> doTestSetValueLong( 0, Long.MIN_VALUE ),
                   () -> doTestSetValueLong( 0, Long.MAX_VALUE ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestSetValueLong( LOWER_LIMIT, 0 ) ;
                       } ) ;   // end assertAll

        }   // end testSetValueLong()


    // ----------


    /**
     * Utility method to start setValue(MyLong) test
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value for the argument instance
     * @param expectedValue
     *     expected resulting context value
     */
    protected void startTestSetValueMyLong( final long contextValue,
                                            final Long argumentValue,
                                            final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).setValue( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \tsetup: argument%s%n\
                  \texpect: context.value: %,d%n\
                  %s\
                  \texpect: %s%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  ( argumentValue == null
                      ? "null"
                      : String.format( "MyLong( %,d )", argumentValue ) ),
                  contextValue,
                  ( argumentValue == null
                      ? ": null"
                      : String.format( ".value: %,d", argumentValue ) ),
                  expectedValue,
                  ( argumentValue == null
                      ? ""
                      : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ),
                  ( ( argumentValue == null ) || willFit( argumentValue )
                      ? "returned: context instance reference"
                      : "thrown: " + OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ;

        }   // end startTestSetValueMyLong()


    /**
     * Utility method to exercise setValue(MyLong)
     *
     * @param contextValue
     *     initial value for value
     * @param newValue
     *     replacement value for value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything setValue() may throw
     */
    protected void doTestSetValueMyLong( final long contextValue,
                                         final Long newValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        assertTimeoutPreemptively( super.testTimeLimit, () ->
            {
            // ensure valid initial state - may effectively result in duplicated tests
            final long constrainedContextValue = constrainValue( contextValue ) ;

            final long expectedResult = ( newValue == null  // DMR TODO reordered test/method
                                                            // invocation - do in all other tests
                ? constrainedContextValue
                : willFit( newValue )
                    ? newValue
                    : constrainedContextValue ) ;

            startTestSetValueMyLong( constrainedContextValue, newValue, expectedResult ) ;

            // instantiate the context instance and set the initial state
            final Object contextInstance = createInstance( constrainedContextValue ) ;

            // instantiate the argument instance and set the initial state
            final Object argumentInstance = ( newValue == null
                ? null
                : createMyLongInstance( newValue ) ) ;

            Object returnedInstance = null ;

            try
                {

                try
                    {    // execute the method
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "setValue",
                                               new Class<?>[]
                                               { MYLONG_CLASS },
                                               argumentInstance ) ;

                    // check if argument value was out of range
                    if ( !willFit( newValue ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try
                catch ( final IllegalArgumentException iae )
                    {

                    // if the argument value is acceptable, shouldn't be here
                    if ( willFit( newValue ) )
                        {
                        throw iae ;  // re-throw the exception
                        }

                    // make sure we're here for the right reason
                    verifyException( iae, OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;

                    // verify context instance state
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;
                    }    // end catch IllegalArgumentException

                // make sure the argument instance is unchanged
                if ( newValue != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", newValue ) ;
                    }

                }
            catch ( final Throwable thrown )
                {
//                   commonExceptionHandler( thrown,    // 2xCk FUTURE
//                                           OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE,
//                                           argumentValue,
//                                           contextInstance, contextValue,
//                                           argumentInstance, argumentValue ) ;

                commonExceptionHandler( thrown, newValue ) ;
                }

            reportEndOfTest() ;
            } ) ;

        }   // end doTestSetValueMyLong()


    /**
     * Test method for setValue(MyLong)
     */
    @Test
    @DisplayName( "setValue(MyLong)" )
    @Order( 40200 )
    protected void testSetValueMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestSetValueMyLong( 0L, 0L ),
                   () -> doTestSetValueMyLong( 101L, 5L ),
                   () -> doTestSetValueMyLong( 123L, -17L ),
                   () -> doTestSetValueMyLong( -321L, -17L ),
                   () -> doTestSetValueMyLong( 25L, 25L ),
                   () -> doTestSetValueMyLong( -34L, 0L ),
                   () -> doTestSetValueMyLong( UPPER_LIMIT, 25L ),
                   () -> doTestSetValueMyLong( 0, Long.MIN_VALUE ),
                   () -> doTestSetValueMyLong( 0, Long.MAX_VALUE ),
                   () -> doTestSetValueMyLong( LOWER_LIMIT, 0L ),
                   () -> doTestSetValueMyLong( 25L, UPPER_LIMIT + 1 ),
                   () -> doTestSetValueMyLong( 25L, LOWER_LIMIT - 1 ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestSetValueMyLong( 25L, null ) ;
                       } ) ;   // end assertAll

        }   // end testSetValueMyLong()


    // ----------


    /**
     * Utility method to start equals(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param compareToValue
     *     value to compare to value
     */
    protected void startTestEqualsLong( final long contextValue,
                                        final long compareToValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).equals( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  compareToValue,
                  contextValue,
                  contextValue == compareToValue ) ;

        }   // end startTestEqualsLong()


    /**
     * Utility method to exercise equals(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param compareToValue
     *     specified value to compare to value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything equals(long) may throw
     */
    protected void doTestEqualsLong( final long contextValue,
                                     final long compareToValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestEqualsLong( constrainedContextValue, compareToValue ) ;

        try
            {
            final boolean expectedResult = ( constrainedContextValue == compareToValue ) ;
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,
                                                                 contextInstance,
                                                                 "equals",
                                                                 new Class<?>[]
                                                                 { long.class },
                                                                 compareToValue ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;


                // verify context instance state is unchanged
                verifyState( contextInstance, "verify", "context", constrainedContextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, compareToValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestEqualsLong()


    /**
     * Test method for equals(long)
     */
    @Test
    @DisplayName( "equals(long)" )
    @Order( 50100 )
    protected void testEqualsLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestEqualsLong( 0L, 0L ),
                   () -> doTestEqualsLong( 1L, 2L ),
                   () -> doTestEqualsLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestEqualsLong( LOWER_LIMIT, UPPER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testEqualsLong()


    // ----------


    /**
     * Utility method to start equals(Object) test with another MyLong
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value for the argument instance
     */
    protected void startTestEqualsMyLong( final long contextValue,
                                          final long argumentValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).equals( %s( %,d ) )%n\
                  \tsetup: context.value: %,d%n\
                  \targument: %s( %,d )%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  super.testClassSimpleName,
                  argumentValue,
                  contextValue,
                  super.testClassSimpleName,
                  argumentValue,
                  contextValue == argumentValue ) ;

        }   // end startTestEqualsMyLong() with another MyLong


    /**
     * Utility method to exercise equals(Object) with another MyLong
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value for the argument instance
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything equals(Object) may throw
     */
    protected void doTestEqualsMyLong( final long contextValue,
                                       final long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestEqualsMyLong( constrainedContextValue, argumentValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // instantiate the argument instance and set the initial state
                final Object argumentInstance = createMyLongInstance( argumentValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 contextInstance,
                                                                 "equals",
                                                                 new Class<?>[]
                                                                 { Object.class },
                                                                 argumentInstance ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( ( contextValue == argumentValue ),
                              returnedResult,
                              "verify return value" ) ;


                // make sure the instance states are correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", contextValue ) ;

                // argument instance
                verifyState( argumentInstance, "verify", "argument", argumentValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestEqualsMyLong() with another MyLong


    /**
     * Test method for equals(java.lang.Object) with another MyLong
     */
    @Test
    @DisplayName( "equals(MyLong)" )
    @Order( 50200 )
    protected void testEqualsMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestEqualsMyLong( 0L, 0L ),
                   () -> doTestEqualsMyLong( 1L, 2L ),
                   () -> doTestEqualsMyLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestEqualsMyLong( LOWER_LIMIT, UPPER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testEqualsMyLong() with another MyLong


    // ----------


    /**
     * Utility method to start equals(Object) test with itself
     *
     * @param contextValue
     *     value for the context instance
     */
    protected void startTestEqualsSelf( final long contextValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).equals( self )%n\
                  \tsetup: context.value: %<,d%n\
                  \tcompare to: self%n\
                  \texpect: returned: true%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue ) ;

        }   // end startTestEqualsSelf()


    /**
     * Utility method to exercise equals(Object) with itself
     *
     * @param contextValue
     *     value for the context instance
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything equals(Object) may throw
     */
    protected void doTestEqualsSelf( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestEqualsSelf( constrainedContextValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 contextInstance,
                                                                 "equals",
                                                                 new Class<?>[]
                                                                 { Object.class },
                                                                 contextInstance ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value - must be true
                assertTrue( returnedResult, "verify return value" ) ;


                // make sure the instance state is correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", contextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestEqualsSelf()


    /**
     * Test method for equals(java.lang.Object) with itself
     */
    @Test
    @DisplayName( "equals(self)" )
    @Order( 50300 )
    protected void testEqualsSelf()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestEqualsSelf( 0L ),
                   () -> doTestEqualsSelf( 2L ),
                   () -> doTestEqualsSelf( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestEqualsSelf( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testEqualsSelf()


    // ----------


    /**
     * Utility method to start equals(Object) test with non-MyLong objects
     *
     * @param contextValue
     *     value for the context instance
     * @param compareToObject
     *     object to compare to the context instance
     */
    protected void startTestEqualsObject( final long contextValue,
                                          final Object compareToObject )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).equals( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: returned: false%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  itemToString( compareToObject ),
                  contextValue ) ;

        }   // end startTestEqualsObject() with non-MyLong objects


    /**
     * Utility method to exercise equals(Object) with non-MyLong objects
     *
     * @param contextValue
     *     value for the context instance
     * @param compareToObject
     *     object to compare to the context instance
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything equals(Object) may throw
     */
    protected void doTestEqualsObject( final long contextValue,
                                       final Object compareToObject )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestEqualsObject( constrainedContextValue, compareToObject ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 contextInstance,
                                                                 "equals",
                                                                 new Class<?>[]
                                                                 { Object.class },
                                                                 compareToObject ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value - must be false
                assertFalse( returnedResult, "verify return value" ) ;


                // make sure the instance state is correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", contextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestEqualsObject() with non-MyLong objects


    /**
     * Test method for equals(java.lang.Object) with non-MyLong objects
     */
    @Test
    @DisplayName( "equals(Object)" )
    @Order( 50400 )
    protected void testEqualsObject()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestEqualsObject( 0L, null ),
                   () -> doTestEqualsObject( 1L, new Long[]
                   { 1L } ),
                   () -> doTestEqualsObject( UPPER_LIMIT, UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestEqualsObject( LOWER_LIMIT, "boom!" ) ;
                       } ) ;   // end assertAll

        }   // end testEqualsObject() with non-MyLong objects

    // ----------


    /**
     * Utility method to start isZero(long) test
     *
     * @param testValue
     *     value to test
     * @param expectedResult
     *     the value isZero() should return
     */
    protected void startTestIsZeroLong( final long testValue,
                                        final boolean expectedResult )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s.isZero( %,d )%n\
                  \ttest value: %<,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  testValue,
                  expectedResult ) ;

        }   // end startTestIsZeroLong()


    /**
     * Utility method to exercise isZero(long)
     *
     * @param testValue
     *     value to test
     * @param expectedResult
     *     the value isZero() should return
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isZero(long) may throw
     */
    protected void doTestIsZeroLong( final long testValue,
                                     final boolean expectedResult )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        startTestIsZeroLong( testValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // execute the method
                final boolean returnedResult = (Boolean) invoke( super.testClass,
                                                                 null,
                                                                 "isZero",
                                                                 new Class<?>[]
                                                                 { long.class },
                                                                 testValue ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, testValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsZeroLong()


    /**
     * Test method for isZero(long)
     */
    @Test
    @DisplayName( "isZero(long)" )
    @Order( 60100 )
    @Disabled            // removed from current assignment
    protected void testIsZeroLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIsZeroLong( 0L, true ),
                   () -> doTestIsZeroLong( 1L, false ),
                   () -> doTestIsZeroLong( UPPER_LIMIT, false ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIsZeroLong( LOWER_LIMIT, false ) ;
                       } ) ;   // end assertAll

        }   // end testIsZeroLong()


    // ----------


    /**
     * Utility method to start isZero() test
     *
     * @param contextValue
     *     value to test
     * @param expectedResult
     *     the value isZero() should return
     */
    protected void startTestIsZero( final long contextValue,
                                    final boolean expectedResult )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).isZero()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  expectedResult ) ;

        }   // end startTestIsZero()


    /**
     * Utility method to exercise isZero()
     *
     * @param contextValue
     *     value to test
     * @param expectedResult
     *     the value isZero() should return
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isZero() may throw
     */
    protected void doTestIsZero( final long contextValue,
                                 final boolean expectedResult )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestIsZero( constrainedContextValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 contextInstance,
                                                                 "isZero" ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;


                // make sure the instance state is correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", contextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsZero()


    /**
     * Test method for isZero()
     */
    @Test
    @DisplayName( "isZero()" )
    @Order( 60200 )
    protected void testIsZero()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIsZero( 0L, true ),
                   () -> doTestIsZero( 1L, false ),
                   () -> doTestIsZero( UPPER_LIMIT, false ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIsZero( LOWER_LIMIT, LOWER_LIMIT == 0 ) ;
                       // conditional required for MyCharacter
                       } ) ;   // end assertAll

        }   // end testIsZero()


    // ----------


    /**
     * Utility method to start isEven(long) test
     *
     * @param testValue
     *     value to test
     * @param expectedResult
     *     the value isEven() should return
     */
    protected void startTestIsEvenLong( final long testValue,
                                        final boolean expectedResult )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s.isEven( %,d )%n\
                  \ttest value: %<,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  testValue,
                  expectedResult ) ;

        }   // end startTestIsEvenLong()


    /**
     * Utility method to exercise isEven(long)
     *
     * @param testValue
     *     value to test
     * @param expectedResult
     *     the value isEven() should return
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isEven(long) may throw
     */
    protected void doTestIsEvenLong( final long testValue,
                                     final boolean expectedResult )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        startTestIsEvenLong( testValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 null,
                                                                 "isEven",
                                                                 new Class<?>[]
                                                                 { long.class },
                                                                 testValue ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, testValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsEvenLong()


    /**
     * Test method for isEven(long)
     */
    @Test
    @DisplayName( "isEven(long)" )
    @Order( 60300 )
    @Disabled                // removed from current assignment
    protected void testIsEvenLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIsEvenLong( 0L, true ),
                   () -> doTestIsEvenLong( 1L, false ),
                   () -> doTestIsEvenLong( 2L, true ),
                   () -> doTestIsEvenLong( -1L, false ),
                   () -> doTestIsEvenLong( -2L, true ),
                   () -> doTestIsEvenLong( UPPER_LIMIT, false ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIsEvenLong( LOWER_LIMIT, true ) ;
                       } ) ;   // end assertAll

        }   // end testIsEvenLong()


    // ----------


    /**
     * Utility method to start isEven() test
     *
     * @param contextValue
     *     value to test
     * @param expectedResult
     *     the value isEven() should return
     */
    protected void startTestIsEven( final long contextValue,
                                    final boolean expectedResult )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).isEven()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  expectedResult ) ;

        }   // end startTestIsEven()


    /**
     * Utility method to exercise isEven()
     *
     * @param contextValue
     *     value to test
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isEven() may throw
     */
    protected void doTestIsEven( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final boolean expectedResult = ( ( constrainedContextValue % 2 ) == 0 ) ;

        startTestIsEven( constrainedContextValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 contextInstance,
                                                                 "isEven" ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;


                // make sure the instance state is correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", constrainedContextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsEven()


    /**
     * Test method for isEven()
     */
    @Test
    @DisplayName( "isEven()" )
    @Order( 60400 )
    protected void testIsEven()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIsEven( 0L ),
                   () -> doTestIsEven( 1L ),
                   () -> doTestIsEven( 2L ),
                   () -> doTestIsEven( -1L ),
                   () -> doTestIsEven( -2L ),
                   () -> doTestIsEven( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIsEven( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testIsEven()


    // ----------


    /**
     * Utility method to start isOdd(long) test
     *
     * @param testValue
     *     value to test
     * @param expectedResult
     *     the value isOdd() should return
     */
    protected void startTestIsOddLong( final long testValue,
                                       final boolean expectedResult )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s.isOdd( %,d )%n\
                  \ttest value: %<,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  testValue,
                  expectedResult ) ;

        }   // end startTestIsOddLong()


    /**
     * Utility method to exercise isOdd(long)
     *
     * @param testValue
     *     value to test
     * @param expectedResult
     *     the value isOdd() should return
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isOdd(long) may throw
     */
    protected void doTestIsOddLong( final long testValue,
                                    final boolean expectedResult )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        startTestIsOddLong( testValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // execute the method
                final boolean returnedResult = (Boolean) invoke( super.testClass,
                                                                 null,
                                                                 "isOdd",
                                                                 new Class<?>[]
                                                                 { long.class },
                                                                 testValue ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, testValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsOddLong()


    /**
     * Test method for isOdd(long)
     */
    @Test
    @DisplayName( "isOdd(long)" )
    @Order( 60500 )
    @Disabled                // removed from current assignment
    protected void testIsOddLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIsOddLong( 0L, false ),
                   () -> doTestIsOddLong( 1L, true ),
                   () -> doTestIsOddLong( 2L, false ),
                   () -> doTestIsOddLong( -1L, true ),
                   () -> doTestIsOddLong( -2L, false ),
                   () -> doTestIsOddLong( UPPER_LIMIT, true ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIsOddLong( LOWER_LIMIT, false ) ;
                       } ) ;   // end assertAll

        }   // end testIsOddLong()


    // ----------


    /**
     * Utility method to start isOdd() test
     *
     * @param contextValue
     *     value to test
     * @param expectedResult
     *     the value isOdd() should return
     */
    protected void startTestIsOdd( final long contextValue,
                                   final boolean expectedResult )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).isOdd()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: returned: %b%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  expectedResult ) ;

        }   // end startTestIsOdd()


    /**
     * Utility method to exercise isOdd()
     *
     * @param contextValue
     *     value to test
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything isOdd() may throw
     */
    protected void doTestIsOdd( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final boolean expectedResult = ( ( constrainedContextValue % 2 ) != 0 ) ;

        startTestIsOdd( constrainedContextValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final boolean returnedResult = (boolean) invoke( super.testClass,    // 2xCk was
                                                                                     // (Boolean)
                                                                 contextInstance,
                                                                 "isOdd" ) ;

                // display the result
                writeLog( "\tactual: returned: %b%n", returnedResult ) ;

                // make sure we have the expected value
                assertEquals( expectedResult, returnedResult, "verify return value" ) ;


                // make sure the instance state is correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", constrainedContextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIsOdd()


    /**
     * Test method for isOdd()
     */
    @Test
    @DisplayName( "isOdd()" )
    @Order( 60600 )
    protected void testIsOdd()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIsOdd( 0L ),
                   () -> doTestIsOdd( 1L ),
                   () -> doTestIsOdd( 2L ),
                   () -> doTestIsOdd( -1L ),
                   () -> doTestIsOdd( -2L ),
                   () -> doTestIsOdd( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIsOdd( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testIsOdd()


    // ----------


    /**
     * Utility method to start increment() test
     *
     * @param contextValue
     *     value to test
     * @param expectedValue
     *     incremented value
     */
    protected void startTestIncrement( final long contextValue,
                                       final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).increment()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: context.value: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  expectedValue ) ;

        }   // end startTestIncrement()


    /**
     * Utility method to exercise increment()
     *
     * @param contextValue
     *     initial instance value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything increment() may throw
     */
    protected void doTestIncrement( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final long expectedValue = constrainValue( constrainedContextValue + 1 ) ;
        // integer overflow if long/Long

        startTestIncrement( constrainedContextValue, expectedValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final Object returnedInstance = invoke( super.testClass,
                                                        contextInstance,
                                                        "increment" ) ;

                // verify context instance state and fluent reference returned
                verifyState( contextInstance, expectedValue, returnedInstance ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestIncrement()


    /**
     * Test method for increment()
     */
    @Test
    @DisplayName( "increment()" )
    @Order( 70100 )
    protected void testIncrement()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestIncrement( 0L ),
                   () -> doTestIncrement( 1L ),
                   () -> doTestIncrement( -1L ),
                   () -> doTestIncrement( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestIncrement( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testIncrement()


    // ----------


    /**
     * Utility method to start decrement() test
     *
     * @param contextValue
     *     value to test
     * @param expectedValue
     *     incremented value
     */
    protected void startTestDecrement( final long contextValue,
                                       final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).decrement()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: context.value: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  expectedValue ) ;

        }   // end startTestDecrement()


    /**
     * Utility method to exercise decrement()
     *
     * @param contextValue
     *     initial instance value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything increment() may throw
     */
    protected void doTestDecrement( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final long expectedValue = constrainValue( constrainedContextValue - 1 ) ;
        // integer underflow if long/Long

        startTestDecrement( constrainedContextValue, expectedValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final Object returnedInstance = invoke( super.testClass,
                                                        contextInstance,
                                                        "decrement" ) ;

                // verify context instance state and fluent reference returned
                verifyState( contextInstance, expectedValue, returnedInstance ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestDecrement()


    /**
     * Test method for decrement()
     */
    @Test
    @DisplayName( "decrement()" )
    @Order( 70200 )
    protected void testDecrement()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestDecrement( 0L ),
                   () -> doTestDecrement( 1L ),
                   () -> doTestDecrement( -1L ),
                   () -> doTestDecrement( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestDecrement( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testDecrement()


    // ----------


    /**
     * Utility method to start add(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param addendValue
     *     value to add to value
     * @param expectedValue
     *     expected resulting sum
     */
    protected void startTestAddLong( final long contextValue,
                                     final long addendValue,
                                     final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).add( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: context.value: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  addendValue,
                  contextValue,
                  expectedValue ) ;

        }   // end startTestAddLong()


    /**
     * Utility method to exercise add(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param addendValue
     *     value to add to value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything add(long) may throw
     */
    protected void doTestAddLong( final long contextValue,
                                  final long addendValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final long expectedResult = constrainValue( constrainedContextValue + addendValue ) ;
        // integer overflow for long/Long

        startTestAddLong( contextValue, addendValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final Object returnedInstance = invoke( super.testClass,
                                                        contextInstance,
                                                        "add",
                                                        new Class<?>[]
                                                        { long.class },
                                                        addendValue ) ;

                // check if addend value was out of range
                if ( !willFit( addendValue ) )
                    {
                    // shouldn't be here - failed to throw exception
                    throw new TestingException( "no exception thrown" ) ;
                    }

                // verify context instance state and fluent reference returned
                verifyState( contextInstance, expectedResult, returnedInstance ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, addendValue ) ;  // 2xCk arg 2
            }

        reportEndOfTest() ;

        }   // end doTestAddLong()


    /**
     * Test method for add(long)
     */
    @Test
    @DisplayName( "add(long)" )
    @Order( 70300 )
    protected void testAddLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestAddLong( 0L, 0L ),
                   () -> doTestAddLong( 1L, 1L ),
                   () -> doTestAddLong( -1L, -1L ),
                   () -> doTestAddLong( -123L, 123L ),
                   () -> doTestAddLong( UPPER_LIMIT, 1L ),
                   () -> doTestAddLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestAddLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestAddLong( LOWER_LIMIT, -1L ) ;
                       } ) ;   // end assertAll

        }   // end testAddLong()


    // ----------


    /**
     * Utility method to start add(MyLong) test
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to add to value
     * @param expectedValue
     *     expected resulting sum
     */
    protected void startTestAddMyLong( final long contextValue,
                                       final Long argumentValue,
                                       final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).add( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \tsetup: argument%s%n\
                  \texpect: context.value: %,d%n\
                  %s\
                  \texpect: %s%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  ( argumentValue == null
                      ? "null"
                      : String.format( "MyLong( %,d )", argumentValue ) ),
                  contextValue,
                  ( argumentValue == null
                      ? ": null"
                      : String.format( ".value: %,d", argumentValue ) ),
                  expectedValue,
                  ( argumentValue == null
                      ? ""
                      : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ),
                  ( ( argumentValue == null ) || willFit( argumentValue )
                      ? "returned: context instance reference"
                      : "thrown: " + OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ;

        }   // end startTestAddMyLong()


    /**
     * Utility method to exercise add(MyLong)
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to add to value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything add(MyLong) may throw
     */
    protected void doTestAddMyLong( final long contextValue,
                                    final Long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        assertTimeoutPreemptively( super.testTimeLimit, () ->
            {
            // ensure valid initial state - may effectively result in duplicated tests
            final long constrainedContextValue = constrainValue( contextValue ) ;

            final long expectedResult = ( argumentValue == null  // DMR TODO reordered test/method
                                                                 // invocation - do in all other
                                                                 // tests
                ? constrainedContextValue
                : willFit( argumentValue )
                    ? constrainValue( constrainedContextValue + argumentValue )
                    : constrainedContextValue ) ;
            // ignore potential integer overflow for long/Long

            startTestAddMyLong( constrainedContextValue, argumentValue, expectedResult ) ;

            // instantiate the context instance and set the initial state
            final Object contextInstance = createInstance( constrainedContextValue ) ;

            // instantiate the argument instance and set the initial state
            final Object argumentInstance = ( argumentValue == null
                ? null
                : createMyLongInstance( argumentValue ) ) ;

            Object returnedInstance = null ;

            try
                {

                try
                    {    // execute the method
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "add",
                                               new Class<?>[]
                                               { MYLONG_CLASS },
                                               argumentInstance ) ;

                    // check if argument value was out of range
                    if ( !willFit( argumentValue ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try
                catch ( final IllegalArgumentException iae )
                    {

                    // if the argument value is acceptable, shouldn't be here
                    if ( willFit( argumentValue ) )
                        {
                        throw iae ;  // re-throw the exception
                        }

                    // make sure we're here for the right reason
                    verifyException( iae, OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;

                    // verify context instance state
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;
                    }    // end catch IllegalArgumentException

                // make sure the argument instance is unchanged
                if ( argumentValue != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", argumentValue ) ;
                    }

                }
            catch ( final Throwable thrown )
                {
//                   commonExceptionHandler( thrown,    // 2xCk FUTURE
//                                           OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE,
//                                           argumentValue,
//                                           contextInstance, contextValue,
//                                           argumentInstance, argumentValue ) ;

                commonExceptionHandler( thrown, argumentValue ) ;
                }

            reportEndOfTest() ;
            } ) ;

        }   // end doTestAddMyLong()


    /**
     * Test method for add(edu.wit.scds.dcsn.comp1050.lab04.MyLong)
     */
    @Test
    @DisplayName( "add(MyLong)" )
    @Order( 70400 )
    protected void testAddMyLong()
        {
        super.lastTestInGroupIsRunning = false ;
        assertAll( () -> doTestAddMyLong( 0L, 0L ),
                   () -> doTestAddMyLong( 1L, 1L ),
                   () -> doTestAddMyLong( -1L, -1L ),
                   () -> doTestAddMyLong( -123L, 123L ),
                   () -> doTestAddMyLong( UPPER_LIMIT, 1L ),
                   () -> doTestAddMyLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestAddMyLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestAddMyLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestAddMyLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestAddMyLong( LOWER_LIMIT, -1L ),
                   () -> doTestAddMyLong( 25L, UPPER_LIMIT + 1 ),
                   () -> doTestAddMyLong( 25L, LOWER_LIMIT - 1 ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestAddMyLong( 25L, null ) ;
                       } ) ;   // end assertAll

        }   // end testAddMyLong()


    // ----------


    /**
     * Utility method to start subtract(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param subtrahendValue
     *     value to subtract from value
     * @param expectedValue
     *     expected resulting difference
     */
    protected void startTestSubtractLong( final long contextValue,
                                          final Long subtrahendValue,
                                          final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).subtract( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: context.value: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  subtrahendValue,
                  contextValue,
                  expectedValue ) ;

        }   // end startTestSubtractLong()


    /**
     * Utility method to exercise subtract(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param subtrahendValue
     *     value to subtract from value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything subtract(long) may throw
     */
    protected void doTestSubtractLong( final long contextValue,
                                       final long subtrahendValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final long expectedResult = constrainValue( constrainedContextValue - subtrahendValue ) ;
        // integer overflow for long/Long

        startTestSubtractLong( constrainedContextValue, subtrahendValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final Object returnedInstance = invoke( super.testClass,
                                                        contextInstance,
                                                        "subtract",
                                                        new Class<?>[]
                                                        { long.class },
                                                        subtrahendValue ) ;

                // verify context instance state and fluent reference returned
                verifyState( contextInstance, expectedResult, returnedInstance ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, subtrahendValue ) ;  // 2xCk arg 2 ) ;
            }

        reportEndOfTest() ;

        }   // end doTestSubtractLong()


    /**
     * Test method for subtract(long)
     */
    @Test
    @DisplayName( "subtract(long)" )
    @Order( 70500 )
    protected void testSubtractLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestSubtractLong( 0L, 0L ),
                   () -> doTestSubtractLong( 1L, 1L ),
                   () -> doTestSubtractLong( -1L, -1L ),
                   () -> doTestSubtractLong( -123L, 123L ),
                   () -> doTestSubtractLong( LOWER_LIMIT, 1L ),
                   () -> doTestSubtractLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestSubtractLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestSubtractLong( 0L, LOWER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestSubtractLong( UPPER_LIMIT, -1L ) ;
                       } ) ;   // end assertAll

        }   // end testSubtractLong()

    // ----------


    /**
     * Utility method to start subtract(MyLong) test
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to subtract from value
     * @param expectedValue
     *     expected resulting difference
     */
    protected void startTestSubtractMyLong( final long contextValue,
                                            final Long argumentValue,
                                            final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).subtract( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \tsetup: argument%s%n\
                  \texpect: context.value: %,d%n\
                  %s\
                  \texpect: %s%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  ( argumentValue == null
                      ? "null"
                      : String.format( "MyLong( %,d )", argumentValue ) ),
                  contextValue,
                  ( argumentValue == null
                      ? ": null"
                      : String.format( ".value: %,d", argumentValue ) ),
                  expectedValue,
                  ( argumentValue == null
                      ? ""
                      : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ),
                  ( ( argumentValue == null ) || willFit( argumentValue )
                      ? "returned: context instance reference"
                      : "thrown: " + OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ;

        }   // end startTestSubtractMyLong()


    /**
     * Utility method to exercise subtract(MyLong)
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to subtract from value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything subtract(MyLong) may throw
     */
    protected void doTestSubtractMyLong( final long contextValue,
                                         final Long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        assertTimeoutPreemptively( super.testTimeLimit, () ->
            {
            // ensure valid initial state - may effectively result in duplicated tests
            final long constrainedContextValue = constrainValue( contextValue ) ;

            final long expectedResult = ( argumentValue == null  // DMR TODO reordered test/method
                                                                 // invocation - do in all other
                                                                 // tests
                ? constrainedContextValue
                : willFit( argumentValue )
                    ? constrainValue( constrainedContextValue - argumentValue )
                    : constrainedContextValue ) ;
            // ignore potential integer overflow for long/Long

            startTestSubtractMyLong( constrainedContextValue, argumentValue, expectedResult ) ;

            // instantiate the context instance and set the initial state
            final Object contextInstance = createInstance( constrainedContextValue ) ;

            // instantiate the argument instance and set the initial state
            final Object argumentInstance = ( argumentValue == null
                ? null
                : createMyLongInstance( argumentValue ) ) ;

            Object returnedInstance = null ;

            try
                {

                try
                    {    // execute the method
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "subtract",
                                               new Class<?>[]
                                               { MYLONG_CLASS },
                                               argumentInstance ) ;

                    // check if argument value was out of range
                    if ( !willFit( argumentValue ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try
                catch ( final IllegalArgumentException iae )
                    {

                    // if the argument value is acceptable, shouldn't be here
                    if ( willFit( argumentValue ) )
                        {
                        throw iae ;  // re-throw the exception
                        }

                    // make sure we're here for the right reason
                    verifyException( iae, OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;

                    // verify context instance state
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;
                    }    // end catch IllegalArgumentException

                // make sure the argument instance is unchanged
                if ( argumentValue != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", argumentValue ) ;
                    }

                }
            catch ( final Throwable thrown )
                {
//                   commonExceptionHandler( thrown,    // 2xCk FUTURE
//                                           OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE,
//                                           argumentValue,
//                                           contextInstance, contextValue,
//                                           argumentInstance, argumentValue ) ;

                commonExceptionHandler( thrown, argumentValue ) ;
                }

            reportEndOfTest() ;
            } ) ;

        }   // end doTestSubtractMyLong()


    /**
     * Test method for subtract(MyLong)
     */
    @Test
    @DisplayName( "subtract(MyLong)" )
    @Order( 70600 )
    protected void testSubtractMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestSubtractMyLong( 0L, 0L ),
                   () -> doTestSubtractMyLong( 1L, 1L ),
                   () -> doTestSubtractMyLong( -1L, -1L ),
                   () -> doTestSubtractMyLong( -123L, 123L ),
                   () -> doTestSubtractMyLong( UPPER_LIMIT, 1L ),
                   () -> doTestSubtractMyLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestSubtractMyLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestSubtractMyLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestSubtractMyLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestSubtractMyLong( LOWER_LIMIT, -1L ),
                   () -> doTestSubtractMyLong( 25L, UPPER_LIMIT + 1 ),
                   () -> doTestSubtractMyLong( 25L, LOWER_LIMIT - 1 ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestSubtractMyLong( 25L, null ) ;
                       } ) ;   // end assertAll

        }   // end testSubtractMyLong()


    // ----------


    /**
     * Utility method to start multiply(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param multiplicandValue
     *     value to multiply value by
     * @param expectedValue
     *     expected resulting sum
     */
    protected void startTestMultiplyLong( final long contextValue,
                                          final long multiplicandValue,
                                          final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).multiply( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: context.value: %,d%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  multiplicandValue,
                  contextValue,
                  expectedValue ) ;

        }   // end startTestMultiplyLong()


    /**
     * Utility method to exercise multiply(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param multiplicandValue
     *     value to multiply value by
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything multiply(long) may throw
     */
    protected void doTestMultiplyLong( final long contextValue,
                                       final long multiplicandValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final long expectedResult = constrainValue( constrainedContextValue * multiplicandValue ) ;
        // integer overflow for long/Long

        startTestMultiplyLong( constrainedContextValue, multiplicandValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final Object returnedInstance = invoke( super.testClass,
                                                        contextInstance,
                                                        "multiply",
                                                        new Class<?>[]
                                                        { long.class },
                                                        multiplicandValue ) ;

                // verify context instance state and fluent reference returned
                verifyState( contextInstance, expectedResult, returnedInstance ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, multiplicandValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestMultiplyLong()


    /**
     * Test method for multiply(long)
     */
    @Test
    @DisplayName( "multiply(long)" )
    @Order( 70700 )
    protected void testMultiplyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestMultiplyLong( 0L, 0L ),
                   () -> doTestMultiplyLong( 1L, 1L ),
                   () -> doTestMultiplyLong( -1L, -1L ),
                   () -> doTestMultiplyLong( -123L, 123L ),
                   () -> doTestMultiplyLong( LOWER_LIMIT, 3L ),
                   () -> doTestMultiplyLong( UPPER_LIMIT, 3L ),
                   () -> doTestMultiplyLong( UPPER_LIMIT, -1L ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestMultiplyLong( LOWER_LIMIT, -1L ) ;
                       } ) ;   // end assertAll

        }   // end testMultiplyLong()


    // ----------


    /**
     * Utility method to start multiply(MyLong) test
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to multiply value by
     * @param expectedValue
     *     expected resulting sum
     */
    protected void startTestMultiplyMyLong( final long contextValue,
                                            final Long argumentValue,
                                            final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).multiply( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \tsetup: argument%s%n\
                  \texpect: context.value: %,d%n\
                  %s\
                  \texpect: %s%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  ( argumentValue == null
                      ? "null"
                      : String.format( "MyLong( %,d )", argumentValue ) ),
                  contextValue,
                  ( argumentValue == null
                      ? ": null"
                      : String.format( ".value: %,d", argumentValue ) ),
                  expectedValue,
                  ( argumentValue == null
                      ? ""
                      : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ),
                  ( ( argumentValue == null ) || willFit( argumentValue )
                      ? "returned: context instance reference"
                      : "thrown: " + OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ;

        }   // end startTestMultiplyMyLong()


    /**
     * Utility method to exercise multiply(MyLong)
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to subtract from value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything multiply(MyLong) may throw
     */
    protected void doTestMultiplyMyLong( final long contextValue,
                                         final Long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        assertTimeoutPreemptively( super.testTimeLimit, () ->
            {
            // ensure valid initial state - may effectively result in duplicated tests
            final long constrainedContextValue = constrainValue( contextValue ) ;

            final long expectedResult = ( argumentValue == null  // DMR TODO reordered test/method
                                                                 // invocation - do in all other
                                                                 // tests
                ? constrainedContextValue
                : willFit( argumentValue )
                    ? constrainValue( constrainedContextValue * argumentValue )
                    : constrainedContextValue ) ;
            // ignore potential integer overflow for long/Long

            startTestMultiplyMyLong( constrainedContextValue, argumentValue, expectedResult ) ;

            // instantiate the context instance and set the initial state
            final Object contextInstance = createInstance( constrainedContextValue ) ;

            // instantiate the argument instance and set the initial state
            final Object argumentInstance = ( argumentValue == null
                ? null
                : createMyLongInstance( argumentValue ) ) ;

            Object returnedInstance = null ;

            try
                {

                try
                    {    // execute the method
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "multiply",
                                               new Class<?>[]
                                               { MYLONG_CLASS },
                                               argumentInstance ) ;

                    // check if argument value was out of range
                    if ( !willFit( argumentValue ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try
                catch ( final IllegalArgumentException iae )
                    {

                    // if the argument value is acceptable, shouldn't be here
                    if ( willFit( argumentValue ) )
                        {
                        throw iae ;  // re-throw the exception
                        }

                    // make sure we're here for the right reason
                    verifyException( iae, OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;

                    // verify context instance state
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;
                    }    // end catch IllegalArgumentException

                // make sure the argument instance is unchanged
                if ( argumentValue != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", argumentValue ) ;
                    }

                }
            catch ( final Throwable thrown )
                {
//                   commonExceptionHandler( thrown,    // 2xCk FUTURE
//                                           OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE,
//                                           argumentValue,
//                                           contextInstance, contextValue,
//                                           argumentInstance, argumentValue ) ;

                commonExceptionHandler( thrown, argumentValue ) ;
                }

            reportEndOfTest() ;
            } ) ;

        }   // end doTestMultiplyMyLong()


    /**
     * Test method for multiply(MyLong)
     */
    @Test
    @DisplayName( "multiply(MyLong)" )
    @Order( 70800 )
    protected void testMultiplyMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestMultiplyMyLong( 0L, 0L ),
                   () -> doTestMultiplyMyLong( 1L, 1L ),
                   () -> doTestMultiplyMyLong( -1L, -1L ),
                   () -> doTestMultiplyMyLong( -123L, 123L ),
                   () -> doTestMultiplyMyLong( LOWER_LIMIT, 3L ),
                   () -> doTestMultiplyMyLong( UPPER_LIMIT, 3L ),
                   () -> doTestMultiplyMyLong( UPPER_LIMIT, -71L ),
                   () -> doTestMultiplyMyLong( LOWER_LIMIT, -7L ),
                   () -> doTestMultiplyMyLong( UPPER_LIMIT, 1L ),
                   () -> doTestMultiplyMyLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestMultiplyMyLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestMultiplyMyLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestMultiplyMyLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestMultiplyMyLong( LOWER_LIMIT, -1L ),
                   () -> doTestMultiplyMyLong( 25L, UPPER_LIMIT + 1 ),
                   () -> doTestMultiplyMyLong( 25L, LOWER_LIMIT - 1 ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestMultiplyMyLong( 25L, null ) ;
                       } ) ;   // end assertAll

        }   // end testMultiplyMyLong()


    // ----------


    /**
     * Utility method to start divide(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param divisorValue
     *     value to divide value by
     * @param expectedValue
     *     expected resulting quotient
     */
    protected void startTestDivideLong( final long contextValue,
                                        final long divisorValue,
                                        final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).divide( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: context.value: %,d%n\
                  %s""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  divisorValue,
                  contextValue,
                  expectedValue,
                  ( divisorValue == 0
                      ? String.format( "\texpect: thrown: %s%n",
                                       DIVISION_BY_ZERO_EXCEPTION_DESCRIPTION )
                      : willFit( divisorValue )
                          ? ""
                          : String.format( "\texpect: thrown: %s%n",
                                           OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ) ;

        }   // end startTestDivideLong()


    /**
     * Utility method to exercise divide(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param divisorValue
     *     value to divide value by
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything divide(long) may throw
     */
    protected void doTestDivideLong( final long contextValue,
                                     final long divisorValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final boolean divisionByZero = divisorValue == 0 ;
        final boolean divisorOutOfRange = !willFit( divisorValue ) ;

        final long expectedResult = ( divisionByZero || divisorOutOfRange
            ? constrainedContextValue
            : constrainValue( constrainedContextValue / divisorValue ) ) ;

        startTestDivideLong( constrainedContextValue, divisorValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                Object returnedInstance = null ;

                try
                    {
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "divide",
                                               new Class<?>[]
                                               { long.class },
                                               divisorValue ) ;

                    // check if operation was division by 0 or value was out of range
                    if ( divisionByZero || divisorOutOfRange )
                        {
                        // shouldn't be here - failed to throw exception
                        throw new TestingException( "no exception thrown" ) ;
                        }

                    // non-0 divisor and divisor in-range

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try()
                catch ( final IllegalArgumentException iae )
                    {

                    // should only be here if division by 0 or divisorValue is out of range
                    if ( !divisionByZero && !divisorOutOfRange )   // 2xCk condition
                        {
                        // shouldn't be here
                        throw iae ;    // re-throw the exception
                        }

                    // was division by 0 or divisor out of range

                    // display the result
                    writeLog( "\tactual: thrown: %s%s%n",
                              iae.getClass().getSimpleName(),
                              ( iae.getMessage() == null
                                  ? ""
                                  : ": " + iae.getMessage() ) ) ;

                    // check the message
                    if ( divisionByZero )
                        {
                        assertEquals( DIVISION_BY_ZERO_EXCEPTION_MESSAGE,
                                      iae.getMessage(),
                                      "message should be: " + DIVISION_BY_ZERO_EXCEPTION_MESSAGE ) ;
                        }
                    else if ( divisorOutOfRange )
                        {
                        assertEquals( OUT_OF_RANGE_EXCEPTION_MESSAGE,
                                      iae.getMessage(),
                                      "message should be: " + OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state is unchanged
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;  // 2xCk
                                                                                           // should
                                                                                           // be
                                                                                           // contextValue
                                                                                           // (unchanged)
                    }    // end catch()

                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, divisorValue ) ; // 2xCk arg 2
            }

        reportEndOfTest() ;

        }   // end doTestDivideLong()


    /**
     * Test method for divide(long)
     */
    @Test
    @DisplayName( "divide(long)" )
    @Order( 70900 )
    protected void testDivideLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestDivideLong( 1L, 1L ),
                   () -> doTestDivideLong( 10L, 2L ),
                   () -> doTestDivideLong( 10L, 3L ),
                   () -> doTestDivideLong( 10L, 15L ),
                   () -> doTestDivideLong( -10L, 4L ),
                   () -> doTestDivideLong( -10L, -4L ),
                   () -> doTestDivideLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestDivideLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestDivideLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestDivideLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestDivideLong( 25L, 0L ),
                   () -> doTestDivideLong( -25L, 0L ),
                   () -> doTestDivideLong( 0L, 0L ),
                   () -> doTestDivideLong( 100L, LOWER_LIMIT - 1 ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestDivideLong( 100L, UPPER_LIMIT + 1 ) ;
                       } ) ;   // end assertAll

        }   // end testDivideLong()


    // ----------


    /**
     * Utility method to start divide(MyLong) test
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to divide value by
     * @param expectedValue
     *     expected resulting sum
     */
    protected void startTestDivideMyLong( final long contextValue,
                                          final Long argumentValue,
                                          final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).divide( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \tsetup: argument%s%n\
                  \texpect: context.value: %,d%n\
                  %s\
                  \texpect: %s%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  ( argumentValue == null
                      ? "null"
                      : String.format( "MyLong( %,d )", argumentValue ) ),
                  contextValue,
                  ( argumentValue == null
                      ? ": null"
                      : String.format( ".value: %,d", argumentValue ) ),
                  expectedValue,
                  ( argumentValue == null
                      ? ""
                      : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ),
                  ( ( argumentValue == null ) ||
                    ( willFit( argumentValue ) && ( argumentValue != 0 ) )
                        ? "returned: context instance reference"
                        : "thrown: " + ( argumentValue == 0
                            ? DIVISION_BY_ZERO_EXCEPTION_DESCRIPTION
                            : OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ) ;

        }   // end startTestDivideMyLong()


    /**
     * Utility method to exercise divide(MyLong)
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to divide value by
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything divide(MyLong) may throw
     */
    protected void doTestDivideMyLong( final long contextValue,
                                       final Long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        assertTimeoutPreemptively( super.testTimeLimit, () ->
            {
            // ensure valid initial state - may effectively result in duplicated tests
            final long constrainedContextValue = constrainValue( contextValue ) ;

            final long expectedResult = ( argumentValue == null  // DMR TODO reordered test/method
                                                                 // invocation - do in all other
                                                                 // tests
                ? constrainedContextValue
                : ( argumentValue == 0 )
                    ? constrainedContextValue
                    : willFit( argumentValue )
                        ? constrainValue( constrainedContextValue / argumentValue )
                        : constrainedContextValue ) ;

            startTestDivideMyLong( constrainedContextValue, argumentValue, expectedResult ) ;

            // instantiate the context instance and set the initial state
            final Object contextInstance = createInstance( constrainedContextValue ) ;

            // instantiate the argument instance and set the initial state
            final Object argumentInstance = ( argumentValue == null
                ? null
                : createMyLongInstance( argumentValue ) ) ;

            Object returnedInstance = null ;

            try
                {

                try
                    {    // execute the method
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "divide",
                                               new Class<?>[]
                                               { MYLONG_CLASS },
                                               argumentInstance ) ;

                    // check if argument value was out of range
                    if ( !willFit( argumentValue ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // check if division by zero
                    if ( ( argumentValue != null ) && ( argumentValue == 0 ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         DIVISION_BY_ZERO_EXCEPTION,
                                         DIVISION_BY_ZERO_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try
                catch ( final IllegalArgumentException iae )
                    {

                    // if the argument value is acceptable (will fit and isn't zero),
                    // then shouldn't be here
                    if ( willFit( argumentValue ) &&
                         ( ( argumentValue != null ) && ( argumentValue != 0 ) ) )
                        {
                        throw iae ;  // re-throw the exception
                        }

                    // make sure we're here for the right reason
                    if ( !willFit( argumentValue ) )     // won't fit
                        {
                        verifyException( iae,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }
                    else if ( ( argumentValue != null ) && ( argumentValue == 0 ) )   // zero
                                                                                      // divisor
                        {
                        verifyException( iae,
                                         DIVISION_BY_ZERO_EXCEPTION,
                                         DIVISION_BY_ZERO_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;
                    }    // end catch IllegalArgumentException

                // make sure the argument instance is unchanged
                if ( argumentValue != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", argumentValue ) ;
                    }

                }
            catch ( final Throwable thrown )
                {
//                   commonExceptionHandler( thrown,    // 2xCk FUTURE
//                                           OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE,
//                                           argumentValue,
//                                           contextInstance, contextValue,
//                                           argumentInstance, argumentValue ) ;

                commonExceptionHandler( thrown, argumentValue ) ;
                }

            reportEndOfTest() ;
            } ) ;

        }   // end doTestDivideMyLong()


    /**
     * Test method for divide(MyLong)
     */
    @Test
    @DisplayName( "divide(MyLong)" )
    @Order( 71000 )
    protected void testDivideMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestDivideMyLong( 0L, 1L ),
                   () -> doTestDivideMyLong( 1L, 1L ),
                   () -> doTestDivideMyLong( -1L, -1L ),
                   () -> doTestDivideMyLong( 10L, 2L ),
                   () -> doTestDivideMyLong( 10L, 3L ),
                   () -> doTestDivideMyLong( 10L, 15L ),
                   () -> doTestDivideMyLong( -10L, 4L ),
                   () -> doTestDivideMyLong( -10L, -4L ),
                   () -> doTestDivideMyLong( -123L, 123L ),
                   () -> doTestDivideMyLong( LOWER_LIMIT, 3L ),
                   () -> doTestDivideMyLong( UPPER_LIMIT, 3L ),
                   () -> doTestDivideMyLong( UPPER_LIMIT, -71L ),
                   () -> doTestDivideMyLong( LOWER_LIMIT, -7L ),
                   () -> doTestDivideMyLong( UPPER_LIMIT, 1L ),
                   () -> doTestDivideMyLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestDivideMyLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestDivideMyLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestDivideMyLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestDivideMyLong( LOWER_LIMIT, -1L ),
                   () -> doTestDivideMyLong( 25L, UPPER_LIMIT + 1 ),
                   () -> doTestDivideMyLong( 25L, LOWER_LIMIT - 1 ),
                   () -> doTestDivideMyLong( 0L, 0L ),
                   () -> doTestDivideMyLong( 25L, 0L ),
                   () -> doTestDivideMyLong( -25L, 0L ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestDivideMyLong( 25L, null ) ;
                       } ) ;   // end assertAll

        }   // end testDivideMyLong()


    // ----------


    /**
     * Utility method to start remainder(long) test
     *
     * @param contextValue
     *     value for the context instance
     * @param divisorValue
     *     value to divide value by
     * @param expectedValue
     *     expected resulting quotient
     */
    protected void startTestRemainderLong( final long contextValue,
                                           final long divisorValue,
                                           final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).remainder( %,d )%n\
                  \tsetup: context.value: %,d%n\
                  \texpect: context.value: %,d%n\
                  %s""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  divisorValue,
                  contextValue,
                  expectedValue,
                  ( divisorValue == 0
                      ? String.format( "\texpect: thrown: %s%n",
                                       DIVISION_BY_ZERO_EXCEPTION_DESCRIPTION )
                      : willFit( divisorValue )
                          ? ""
                          : String.format( "\texpect: thrown: %s%n",
                                           OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ) ;

        }   // end startTestRemainderLong()


    /**
     * Utility method to exercise remainder(long)
     *
     * @param contextValue
     *     value for the context instance
     * @param divisorValue
     *     value to divide value by
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything remainder(long) may throw
     */
    protected void doTestRemainderLong( final long contextValue,
                                        final long divisorValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        final boolean divisionByZero = divisorValue == 0 ;
        final boolean divisorOutOfRange = !willFit( divisorValue ) ;

        final long expectedResult = ( divisionByZero || divisorOutOfRange
            ? constrainedContextValue
            : constrainValue( constrainedContextValue % divisorValue ) ) ;

        startTestRemainderLong( constrainedContextValue, divisorValue, expectedResult ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate the context instance and set the initial state
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                Object returnedInstance = null ;

                try
                    {
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "remainder",
                                               new Class<?>[]
                                               { long.class },
                                               divisorValue ) ;

                    // check if operation was division by 0 or value was out of range
                    if ( divisionByZero || divisorOutOfRange )
                        {
                        // shouldn't be here - failed to throw exception
                        throw new TestingException( "no exception thrown" ) ;
                        }

                    // non-0 divisor and divisor in-range

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try()
                catch ( final IllegalArgumentException iae )
                    {

                    // should only be here if division by 0 or divisorValue is out of range
                    if ( !divisionByZero && !divisorOutOfRange )   // 2xCk condition
                        {
                        // shouldn't be here
                        throw iae ;    // re-throw the exception
                        }

                    // was division by 0 or divisor out of range

                    // display the result
                    writeLog( "\tactual: thrown: %s%s%n",
                              iae.getClass().getSimpleName(),
                              ( iae.getMessage() == null
                                  ? ""
                                  : ": " + iae.getMessage() ) ) ;

                    // check the message
                    if ( divisionByZero )
                        {
                        assertEquals( DIVISION_BY_ZERO_EXCEPTION_MESSAGE,
                                      iae.getMessage(),
                                      "message should be: " + DIVISION_BY_ZERO_EXCEPTION_MESSAGE ) ;
                        }
                    else if ( divisorOutOfRange )
                        {
                        assertEquals( OUT_OF_RANGE_EXCEPTION_MESSAGE,
                                      iae.getMessage(),
                                      "message should be: " + OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state is unchanged
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;  // 2xCk
                                                                                           // should
                                                                                           // be
                                                                                           // contextValue
                                                                                           // (unchanged)
                    }    // end catch()

                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, divisorValue ) ; // 2xCk arg 2
            }

        reportEndOfTest() ;

        }   // end doTestRemainderLong()


    /**
     * Test method for remainder(long)
     */
    @Test
    @DisplayName( "remainder(long)" )
    @Order( 71100 )
    protected void testRemainderLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestRemainderLong( 1L, 1L ),
                   () -> doTestRemainderLong( 10L, 2L ),
                   () -> doTestRemainderLong( 10L, 3L ),
                   () -> doTestRemainderLong( 10L, 15L ),
                   () -> doTestRemainderLong( -10L, 4L ),
                   () -> doTestRemainderLong( -10L, -4L ),
                   () -> doTestRemainderLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestRemainderLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestRemainderLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestRemainderLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestRemainderLong( 25L, 0L ),
                   () -> doTestRemainderLong( -25L, 0L ),
                   () -> doTestRemainderLong( 0L, 0L ),
                   () -> doTestRemainderLong( 100L, LOWER_LIMIT - 1 ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestRemainderLong( 100L, UPPER_LIMIT + 1 ) ;
                       } ) ;   // end assertAll

        }   // end testRemainderLong()


    // ----------


    /**
     * Utility method to start remainder(MyLong) test
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to divide value by
     * @param expectedValue
     *     expected resulting sum
     */
    protected void startTestRemainderMyLong( final long contextValue,
                                             final Long argumentValue,
                                             final long expectedValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).remainder( %s )%n\
                  \tsetup: context.value: %,d%n\
                  \tsetup: argument%s%n\
                  \texpect: context.value: %,d%n\
                  %s\
                  \texpect: %s%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue,
                  ( argumentValue == null
                      ? "null"
                      : String.format( "MyLong( %,d )", argumentValue ) ),
                  contextValue,
                  ( argumentValue == null
                      ? ": null"
                      : String.format( ".value: %,d", argumentValue ) ),
                  expectedValue,
                  ( argumentValue == null
                      ? ""
                      : String.format( "\texpect: argument.value: %,d%n", argumentValue ) ),
                  ( ( argumentValue == null ) ||
                    ( willFit( argumentValue ) && ( argumentValue != 0 ) )
                        ? "returned: context instance reference"
                        : "thrown: " + ( argumentValue == 0
                            ? DIVISION_BY_ZERO_EXCEPTION_DESCRIPTION
                            : OUT_OF_RANGE_EXCEPTION_DESCRIPTION ) ) ) ;

        }   // end startTestRemainderMyLong()


    /**
     * Utility method to exercise remainder(MyLong)
     *
     * @param contextValue
     *     value for the context instance
     * @param argumentValue
     *     value to divide value by
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything remainder(MyLong) may throw
     */
    protected void doTestRemainderMyLong( final long contextValue,
                                          final Long argumentValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {
        assertTimeoutPreemptively( super.testTimeLimit, () ->
            {
            // ensure valid initial state - may effectively result in duplicated tests
            final long constrainedContextValue = constrainValue( contextValue ) ;

            final long expectedResult = ( argumentValue == null  // DMR TODO reordered test/method
                                                                 // invocation - do in all other
                                                                 // tests
                ? constrainedContextValue
                : ( argumentValue == 0 )
                    ? constrainedContextValue
                    : willFit( argumentValue )
                        ? constrainValue( constrainedContextValue % argumentValue )
                        : constrainedContextValue ) ;

            startTestRemainderMyLong( constrainedContextValue, argumentValue, expectedResult ) ;

            // instantiate the context instance and set the initial state
            final Object contextInstance = createInstance( constrainedContextValue ) ;

            // instantiate the argument instance and set the initial state
            final Object argumentInstance = ( argumentValue == null
                ? null
                : createMyLongInstance( argumentValue ) ) ;

            Object returnedInstance = null ;

            try
                {

                try
                    {    // execute the method
                    returnedInstance = invoke( super.testClass,
                                               contextInstance,
                                               "remainder",
                                               new Class<?>[]
                                               { MYLONG_CLASS },
                                               argumentInstance ) ;

                    // check if argument value was out of range
                    if ( !willFit( argumentValue ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }

                    // check if division by zero
                    if ( ( argumentValue != null ) && ( argumentValue == 0 ) )
                        {
                        // shouldn't be here - failed to throw exception
                        verifyException( null,
                                         DIVISION_BY_ZERO_EXCEPTION,
                                         DIVISION_BY_ZERO_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state and fluent reference returned
                    verifyState( contextInstance, expectedResult, returnedInstance ) ;
                    }    // end try
                catch ( final IllegalArgumentException iae )
                    {

                    // if the argument value is acceptable (will fit and isn't zero),
                    // then shouldn't be here
                    if ( willFit( argumentValue ) &&
                         ( ( argumentValue != null ) && ( argumentValue != 0 ) ) )
                        {
                        throw iae ;  // re-throw the exception
                        }

                    // make sure we're here for the right reason
                    if ( !willFit( argumentValue ) )     // won't fit
                        {
                        verifyException( iae,
                                         OUT_OF_RANGE_EXCEPTION,
                                         OUT_OF_RANGE_EXCEPTION_MESSAGE ) ;
                        }
                    else if ( ( argumentValue != null ) && ( argumentValue == 0 ) )   // zero
                                                                                      // divisor
                        {
                        verifyException( iae,
                                         DIVISION_BY_ZERO_EXCEPTION,
                                         DIVISION_BY_ZERO_EXCEPTION_MESSAGE ) ;
                        }

                    // verify context instance state
                    verifyState( contextInstance, "verify", "context", expectedResult ) ;
                    }    // end catch IllegalArgumentException

                // make sure the argument instance is unchanged
                if ( argumentValue != null )
                    {
                    verifyState( argumentInstance, "verify", "argument", argumentValue ) ;
                    }

                }
            catch ( final Throwable thrown )
                {
//                   commonExceptionHandler( thrown,    // 2xCk FUTURE
//                                           OUT_OF_RANGE_EXCEPTION, OUT_OF_RANGE_EXCEPTION_MESSAGE,
//                                           argumentValue,
//                                           contextInstance, contextValue,
//                                           argumentInstance, argumentValue ) ;

                commonExceptionHandler( thrown, argumentValue ) ;
                }

            reportEndOfTest() ;
            } ) ;

        }   // end doTestRemainderMyLong()


    /**
     * Test method for remainder(MyLong)
     */
    @Test
    @DisplayName( "remainder(MyLong)" )
    @Order( 71200 )
    protected void testRemainderMyLong()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestRemainderMyLong( 0L, 1L ),
                   () -> doTestRemainderMyLong( 1L, 1L ),
                   () -> doTestRemainderMyLong( -1L, -1L ),
                   () -> doTestRemainderMyLong( 10L, 2L ),
                   () -> doTestRemainderMyLong( 10L, 3L ),
                   () -> doTestRemainderMyLong( 10L, 15L ),
                   () -> doTestRemainderMyLong( -10L, 4L ),
                   () -> doTestRemainderMyLong( -10L, -4L ),
                   () -> doTestRemainderMyLong( -123L, 123L ),
                   () -> doTestRemainderMyLong( LOWER_LIMIT, 3L ),
                   () -> doTestRemainderMyLong( UPPER_LIMIT, 3L ),
                   () -> doTestRemainderMyLong( UPPER_LIMIT, -71L ),
                   () -> doTestRemainderMyLong( LOWER_LIMIT, -7L ),
                   () -> doTestRemainderMyLong( UPPER_LIMIT, 1L ),
                   () -> doTestRemainderMyLong( UPPER_LIMIT, LOWER_LIMIT ),
                   () -> doTestRemainderMyLong( UPPER_LIMIT, UPPER_LIMIT ),
                   () -> doTestRemainderMyLong( LOWER_LIMIT, UPPER_LIMIT ),
                   () -> doTestRemainderMyLong( LOWER_LIMIT, LOWER_LIMIT ),
                   () -> doTestRemainderMyLong( LOWER_LIMIT, -1L ),
                   () -> doTestRemainderMyLong( 25L, UPPER_LIMIT + 1 ),
                   () -> doTestRemainderMyLong( 25L, LOWER_LIMIT - 1 ),
                   () -> doTestRemainderMyLong( 0L, 0L ),
                   () -> doTestRemainderMyLong( 25L, 0L ),
                   () -> doTestRemainderMyLong( -25L, 0L ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestRemainderMyLong( 25L, null ) ;
                       } ) ;   // end assertAll

        }   // end testRemainderMyLong()


    // ----------


    /**
     * Utility method to start toString() test
     *
     * @param contextValue
     *     value for value
     */
    protected void startTestToString( final long contextValue )
        {
        // count this test
        super.currentTestsAttempted++ ;

        // display message describing this test
        writeLog( """
                  %s%s( %,d ).toString()%n\
                  \tsetup: context.value: %<,d%n\
                  \texpect: returned: "%<,d"%n""",
                  startTestHeaderMessage(),
                  super.testClassSimpleName,
                  contextValue ) ;

        }   // end startTestToString()


    /**
     * Utility method to exercise toString()
     *
     * @param contextValue
     *     value for value
     *
     * @throws IllegalAccessException
     *     if the field access isn't permitted
     * @throws IllegalArgumentException
     *     if one of the arguments to retrieve the field is invalid
     * @throws NoSuchFieldException
     *     if the specified field can't be found in the given object
     * @throws SecurityException
     *     if the specified field exists but isn't accessible
     * @throws Throwable
     *     anything toString() may throw
     */
    void doTestToString( final long contextValue )
        throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
        SecurityException, Throwable
        {    // DMR 2xCk make sure using appropriate methods/tests/etc
        // ensure valid initial state - may effectively result in duplicated tests
        final long constrainedContextValue = constrainValue( contextValue ) ;

        startTestToString( constrainedContextValue ) ;

        try
            {
            assertTimeoutPreemptively( super.testTimeLimit, () ->
                {
                // instantiate a MyLong object
                final Object contextInstance = createInstance( constrainedContextValue ) ;

                // execute the method
                final String actualResult = (String) invoke( super.testClass,
                                                             contextInstance,
                                                             "toString" ) ;


                // display the result with quotes
                writeLog( "\tactual: returned: %s%n", itemToString( actualResult ) ) ;

                // make sure we have the expected text
                assertEquals( String.format( "%,d", constrainedContextValue ),
                              actualResult,
                              "verify return value" ) ;


                // make sure the instance state is correct/unchanged

                // context instance
                verifyState( contextInstance, "verify", "context", constrainedContextValue ) ;
                } ) ;
            }
        catch ( final Throwable thrown )
            {
            commonExceptionHandler( thrown, contextValue ) ;
            }

        reportEndOfTest() ;

        }   // end doTestToString()


    /**
     * Test method for toString()
     */
    @Test
    @DisplayName( "toString()" )
    @Order( 90100 )
    void testToString()
        {
        super.lastTestInGroupIsRunning = false ;

        assertAll( () -> doTestToString( 0L ),
                   () -> doTestToString( Byte.MAX_VALUE ),
                   () -> doTestToString( Byte.MIN_VALUE ),
                   () -> doTestToString( Short.MAX_VALUE ),
                   () -> doTestToString( Short.MIN_VALUE ),
                   () -> doTestToString( UPPER_LIMIT ),
                   () ->
                       {
                       super.lastTestInGroupIsRunning = true ;

                       doTestToString( LOWER_LIMIT ) ;
                       } ) ;   // end assertAll

        }   // end testToString()


    // ----------

    /*
     * utility methods
     */


    /**
     * Convenience method for common exception handler without {@code testValue}
     *
     * @param thrown
     *     the caught object
     *
     * @throws Throwable
     *     the caught object
     */
    protected void commonExceptionHandler( final Throwable thrown ) throws Throwable
        {
        commonExceptionHandler( thrown, null ) ;

        }    // end commonExceptionHandler()


    /**
     * Common exception handler
     *
     * @param thrown
     *     the caught object
     * @param testValue
     *     if provided, determines whether exception is (in)correct behavior
     *
     * @throws Throwable
     *     the caught object
     */
    protected void commonExceptionHandler( final Throwable thrown,
                                           final Long testValue )
        throws Throwable
        {
        final String thrownMessage = thrown.getMessage() ;

        writeLog( "\tactual: thrown: %s%s%n",
                  thrown.getClass().getSimpleName(),
                  thrownMessage == null
                      ? ""
                      : ": " + thrownMessage ) ;

        // only a failure if we get an unexpected exception
        // we expect an IllegalArgumentException when the testValue won't fit
        if ( ( testValue == null ) || !rangeViolationCorrectlyHandled( thrown, testValue ) )
            {

            if ( super.lastTestInGroupIsRunning )
                {
                super.currentTestPassed = false ;
                }
            else
                {
                testFailed() ;
                }

            throw thrown ;   // re-throw it
            }

        }    // end commonExceptionHandler()


    /**
     * @param thrown
     *     the caught object
     * @param testValue
     *     if provided, determines whether exception is (in)correct behavior
     * @param contextReference
     *     a reference to the instance to the method under test
     * @param contextValue
     *     the expected value {@code contextReference} should contain
     * @param argumentReference
     *     if non-null, a reference to the instance pass as an argument to the method under test
     * @param argumentValue
     *     if {@code argumentReference} is non-null, the value it should contain
     *
     * @throws Throwable
     *     the caught object
     */
    protected void commonExceptionHandler( final Throwable thrown,
                                           final Long testValue,
                                           final Object contextReference,
                                           final long contextValue,
                                           final Object argumentReference,
                                           final Long argumentValue )
        throws Throwable
        {
        commonExceptionHandler( thrown,
                                OUT_OF_RANGE_EXCEPTION,
                                OUT_OF_RANGE_EXCEPTION_MESSAGE,
                                testValue,
                                contextReference,
                                contextValue,
                                argumentReference,
                                argumentValue ) ;

        }    // end 6-arg commonExceptionHandler()


    /**
     * Common exception handler
     *
     * @param thrown
     *     the caught object
     * @param expectedThrown
     *     the exception that should have been thrown
     * @param expectedThrownMessage
     *     the message that should be included in the exception
     * @param testValue
     *     if provided, determines whether exception is (in)correct behavior
     * @param contextReference
     *     a reference to the instance to the method under test
     * @param contextValue
     *     the expected value {@code contextReference} should contain
     * @param argumentReference
     *     if non-null, a reference to the instance pass as an argument to the method under test
     * @param argumentValue
     *     if {@code argumentReference} is non-null, the value it should contain
     *
     * @throws Throwable
     *     the caught object
     */
    protected void commonExceptionHandler( final Throwable thrown,
                                           final Class<?> expectedThrown,
                                           final String expectedThrownMessage,
                                           final Long testValue,
                                           final Object contextReference,
                                           final long contextValue,
                                           final Object argumentReference,
                                           final Long argumentValue )
        throws Throwable
        {
        final String thrownMessage = thrown.getMessage() ;

        writeLog( "\tactual: %s%s%n",
                  thrown.getClass().getSimpleName(),
                  thrownMessage == null
                      ? ""
                      : ": " + thrownMessage ) ;

        // make sure the context instance is unchanged
        verifyState( contextReference, "verify", "context", contextValue ) ;

        // if provided, make sure the argument instance is unchanged
        if ( argumentReference != null )
            {
            verifyState( argumentReference, "verify", "argument", argumentValue ) ;
            }

        // only a failure if we get an unexpected exception or message
        // we expect an IllegalArgumentException when the testValue won't fit or the divisor is 0
        if ( rangeViolationCorrectlyHandled( thrown, testValue ) )
            {
            return ;     // correct behavior - no problem
//               throw thrown ;   // re-throw it
            }

        try
            {
            verifyException( thrown, expectedThrown, expectedThrownMessage ) ;
            }
        catch ( @SuppressWarnings( "unused" ) final Throwable newThrown )
            {

            if ( super.lastTestInGroupIsRunning )
                {
                super.currentTestPassed = false ;
                }
            else
                {
                testFailed() ;
                }

            }

        throw thrown ;   // re-throw it

        }    // end 8-arg commonExceptionHandler()


    /**
     * Ensure the correct exception and message were thrown
     *
     * @param actualThrown
     *     the exception/throwable that was caught
     * @param expectedThrown
     *     the exception that should have been thrown
     * @param expectedThrownMessage
     *     the message that should be included in the exception
     */
    protected void verifyException( final Throwable actualThrown,
                                    final Class<?> expectedThrown,
                                    final String expectedThrownMessage )
        {

        if ( ( expectedThrown == null ) && ( actualThrown == null ) )
            {
            return ;     // nothing to check
            }

        if ( actualThrown == null )
            {
            throw new TestingException( "no exception thrown" ) ;
            }

        // assertion: we have a thrown instance

        final Class<?> actualThrownType = actualThrown.getClass() ;
        final String actualThrownTypeName = actualThrownType.getSimpleName() ;
        final String actualThrownMessage = actualThrown.getMessage() ;

        if ( expectedThrown == null )
            {
            throw new TestingException( "unexpected exception thrown: " + actualThrownTypeName +
                                        ( actualThrownMessage == null
                                            ? ""
                                            : ": " + actualThrownMessage ) ) ;
            }

        if ( !actualThrownType.equals( expectedThrown ) )
            {
            throw new TestingException( "incorrect exception thrown: " + actualThrownTypeName ) ;
            }

        if ( actualThrownMessage == null )
            {

            if ( expectedThrownMessage != null )
                {
                throw new TestingException( "missing exception message" ) ;
                }

            }
        else if ( !actualThrownMessage.equals( expectedThrownMessage ) )
            {
            throw new TestingException( "incorrect exception message: " + actualThrownMessage ) ;
            }

        // thrown exception and message match expected
        writeLog( "\tactual: thrown: %s%s%n",
                  actualThrownTypeName,
                  ( actualThrownMessage == null
                      ? ""
                      : ": " + actualThrownMessage ) ) ;

        }    // end verifyException()


    /**
     * Common test header message formatting
     *
     * @return text describing the start of a test
     */
    protected String startTestHeaderMessage()
        {
        return String.format( "%n[%,d, %,d] Testing: ",
                              super.currentTestGroup,
                              super.currentTestsAttempted ) ;

        }    // end startTestHeaderMessage()


    /**
     * Common end-of-test processing
     */
    protected void reportEndOfTest()
        {

        if ( super.lastTestInGroupIsRunning )
            {
            super.currentTestPassed = true ;
            }
        else
            {
            testPassed() ;
            }

        }    // end endTest()


    /**
     * convenience method to create an instance of the test class with the default state
     *
     * @return reference to the new instance
     *
     * @throws TestingException
     *     wrapper for lower-level exception
     * @throws Throwable
     *     catch-all for anything else thrown
     */
    protected Object createInstance() throws TestingException, Throwable
        {
        return createInstance( VALUE_DEFAULT ) ;

        }    // end createInstance()


    /**
     * create an instance of the test class with the specified state
     *
     * @param initialValue
     *     initial contents of {@code value} data field
     *
     * @return reference to the new instance
     *
     * @throws TestingException
     *     wrapper for lower-level exception
     * @throws Throwable
     *     catch-all for anything else thrown
     */
    protected Object createInstance( final long initialValue ) throws TestingException, Throwable
        {
        // instantiate the context instance and set the initial state
        final Object newInstance = instantiate( super.testClass ) ;
        setLongField( newInstance, "value", initialValue ) ;

        return newInstance ;

        }    // end createInstance()


    /**
     * convenience method to create an instance of the test class' superclass with the default state
     *
     * @return reference to the new instance
     *
     * @throws TestingException
     *     wrapper for lower-level exception
     * @throws Throwable
     *     catch-all for anything else thrown
     */
    protected Object createSuperInstance() throws TestingException, Throwable
        {
        return createSuperInstance( VALUE_DEFAULT ) ;

        }    // end createSuperInstance()


    /**
     * create an instance of the test class' superclass with the specified state
     *
     * @param initialValue
     *     initial contents of {@code value} data field
     *
     * @return reference to the new instance
     *
     * @throws TestingException
     *     wrapper for lower-level exception
     * @throws Throwable
     *     catch-all for anything else thrown
     */
    protected Object createSuperInstance( final long initialValue )
        throws TestingException, Throwable
        {
        // instantiate the context instance and set the initial state
        final Object newInstance = instantiate( super.testSuperClass == Object.class
            ? super.testClass
            : super.testSuperClass ) ;
        setLongField( newInstance, "value", initialValue ) ;

        return newInstance ;

        }    // end createSuperInstance()


    /**
     * convenience method to create an instance of MyLong with the default state
     *
     * @return reference to the new instance
     *
     * @throws TestingException
     *     wrapper for lower-level exception
     * @throws Throwable
     *     catch-all for anything else thrown
     */
    protected static Object createMyLongInstance() throws TestingException, Throwable
        {
        return createMyLongInstance( VALUE_DEFAULT ) ;

        }    // end createMyLongInstance()


    /**
     * create an instance of MyLong with the specified state
     *
     * @param initialValue
     *     initial contents of {@code value} data field
     *
     * @return reference to the new instance
     *
     * @throws TestingException
     *     wrapper for lower-level exception
     * @throws Throwable
     *     catch-all for anything else thrown
     */
    protected static Object createMyLongInstance( final long initialValue )
        throws TestingException, Throwable
        {
        // instantiate the context instance and set the initial state
        final Object newInstance = instantiate( MYLONG_CLASS ) ;
        setLongField( newInstance, "value", initialValue ) ;

        return newInstance ;

        }    // end createMyLongInstance()


    /**
     * convenience method to determine if the argument will fit in the test class' type
     *
     * @param candidateValue
     *     the value to test
     *
     * @return true if candidateValue will fit in the test class' type; false if it won't fit
     */
    protected static boolean willFit( final long candidateValue )
        {
        return willFit( candidateValue, LOWER_LIMIT, UPPER_LIMIT ) ;

        }    // end 1-arg willFit(long)


    /**
     * convenience method to determine if the argument will fit in the test class' type
     *
     * @param candidateValue
     *     the value to test
     *
     * @return true if candidateValue will fit in the test class' type; false if it won't fit
     */
    protected static boolean willFit( final Long candidateValue )
        {
        return ( candidateValue == null ) || willFit( (long) candidateValue ) ;

        }    // end 1-arg willFit(Long)


    /**
     * determine if the argument will fit in the specified range
     *
     * @param candidateValue
     *     the value to test
     * @param lowerLimit
     *     the smallest value in the range
     * @param upperLimit
     *     the largest value in the range
     *
     * @return true if candidateValue will fit in the test class' type; false if it won't fit
     */
    protected static boolean willFit( final long candidateValue,
                                      final long lowerLimit,
                                      final long upperLimit )
        {
        return ( candidateValue >= lowerLimit ) && ( candidateValue <= upperLimit ) ;

        }    // end 3-arg willFit(long)


    /**
     * determine if the argument will fit in the specified range
     *
     * @param candidateValue
     *     the value to test
     * @param lowerLimit
     *     the smallest value in the range
     * @param upperLimit
     *     the largest value in the range
     *
     * @return true if candidateValue will fit in the test class' type; false if it won't fit
     */
    protected static boolean willFit( final Long candidateValue,
                                      final long lowerLimit,
                                      final long upperLimit )
        {
        return ( candidateValue == null ) ||
               willFit( (long) candidateValue, lowerLimit, upperLimit ) ;

        }    // end 3-arg willFit(Long)


    /**
     * determine if a division by zero error was correctly reported
     *
     * @param thrown
     *     the thrown object
     * @param testDivisor
     *     the value to test for zero - must be non-null
     *
     * @return true if a division by zero error was correctly reported; false otherwise
     */
    protected static boolean divisionByZeroCorrectlyHandled( final Throwable thrown,
                                                             final Long testDivisor )
        {
        return ( testDivisor != null ) && ( testDivisor == 0 ) &&
               DIVISION_BY_ZERO_EXCEPTION.equals( thrown.getClass() ) &&
               DIVISION_BY_ZERO_EXCEPTION_MESSAGE.equals( thrown.getMessage() ) ;

        }    // end divisionByZeroCorrectlyHandled()


    /**
     * determine if a range error was correctly reported
     *
     * @param thrown
     *     the thrown object
     * @param testValue
     *     the value to test for in/out-of-range - must be non-null
     *
     * @return true if a range error was correctly reported; false otherwise
     */
    protected static boolean rangeViolationCorrectlyHandled( final Throwable thrown,
                                                             final Long testValue )
        {
        return ( testValue != null ) && !willFit( testValue ) &&
               OUT_OF_RANGE_EXCEPTION.equals( thrown.getClass() ) &&
               OUT_OF_RANGE_EXCEPTION_MESSAGE.equals( thrown.getMessage() ) ;

        }    // end rangeViolationCorrectlyHandled()


    /**
     * Constrain the {@code candidateValue} to the test's specified lower and upper limits
     *
     * @param candidateValue
     *     the value to constrain
     *
     * @return the constrained value
     */
    protected static long constrainValue( final long candidateValue )
        {
        return constrainValue( candidateValue, LOWER_LIMIT, UPPER_LIMIT ) ;

        }    // end constrainValue()


    /**
     * Constrain the {@code candidateValue} to the specified limits
     *
     * @param candidateValue
     *     the value to constrain
     * @param lowerLimit
     *     the smallest acceptable value
     * @param upperLimit
     *     the largest acceptable value
     *
     * @return the constrained value
     */
    protected static long constrainValue( final long candidateValue,
                                          final long lowerLimit,
                                          final long upperLimit )
        {
        return Math.max( lowerLimit, Math.min( upperLimit, candidateValue ) ) ;

        }    // end constrainValue()


    /**
     * Convenience method to verify the state of an instance and optionally test the fluent
     * reference returned - provides an {@code instanceDescription} of {@code "actual: context"} and
     * no {@code fluentReference}
     *
     * @param testInstance
     *     the instance to verify
     * @param expectedValue
     *     expected contents of the {@code value} field
     */
    protected void verifyState( final Object testInstance,
                                final long expectedValue )
        {
        verifyState( testInstance, "actual", "context", expectedValue, false, null ) ;

        }    // end verifyState()


    /**
     * Convenience method to verify the state of an instance and optionally test the fluent
     * reference returned - provides no {@code fluentReference}
     *
     * @param testInstance
     *     the instance to verify
     * @param phaseDescription
     *     description of testing phase
     * @param instanceDescription
     *     description of test instance's purpose
     * @param expectedValue
     *     expected contents of the {@code value} field
     */
    protected void verifyState( final Object testInstance,
                                final String phaseDescription,
                                final String instanceDescription,
                                final long expectedValue )
        {
        verifyState( testInstance,
                     phaseDescription,
                     instanceDescription,
                     expectedValue,
                     false,
                     null ) ;

        }    // end verifyState()


    /**
     * Convenience method to verify the state of an instance and optionally test the fluent
     * reference returned - provides an {@code instanceDescription} of {@code "actual: context"}
     *
     * @param testInstance
     *     the instance to verify
     * @param expectedValue
     *     expected contents of the {@code value} field
     * @param fluentReference
     *     optional fluent reference - if provided, should match the testInstance reference
     */
    protected void verifyState( final Object testInstance,
                                final long expectedValue,
                                final Object fluentReference )
        {
        verifyState( testInstance, "actual", "context", expectedValue, true, fluentReference ) ;

        }    // end verifyState()


    /**
     * Convenience method to verify the state of an instance and optionally test the fluent
     * reference returned - provides an {@code instanceDescription} of {@code "actual: context"}
     *
     * @param testInstance
     *     the instance to verify
     * @param phaseDescription
     *     description of testing phase
     * @param instanceDescription
     *     description of test instance's purpose
     * @param expectedValue
     *     expected contents of the {@code value} field
     * @param fluentReference
     *     optional fluent reference - if provided, should match the testInstance reference
     */
    protected void verifyState( final Object testInstance,
                                final String phaseDescription,
                                final String instanceDescription,
                                final long expectedValue,
                                final Object fluentReference )
        {
        verifyState( testInstance,
                     phaseDescription,
                     instanceDescription,
                     expectedValue,
                     true,
                     fluentReference ) ;

        }    // end verifyState()


    /**
     * Verify the state of an instance and optionally test the fluent reference returned
     *
     * @param testInstance
     *     the instance to verify
     * @param phaseDescription
     *     description of testing phase
     * @param instanceDescription
     *     description of test instance's purpose
     * @param expectedValue
     *     expected contents of the {@code value} field
     * @param fluentMethod
     *     if true, the method under test is fluent/must return a reference to the context instance;
     *     if false, fluentReference must be {@code null}
     * @param fluentReference
     *     optional fluent reference - if provided, should match the testInstance reference
     */
    protected void verifyState( final Object testInstance,
                                final String phaseDescription,
                                final String instanceDescription,
                                final long expectedValue,
                                final boolean fluentMethod,
                                final Object fluentReference )
        {
        /*
         * check context instance state
         */

        // retrieve the instance state for verification
        final long fieldValue = getLongField( testInstance, "value" ) ;

        // display the actual values
        writeLog( "\t%s: %s.value: %,d%n", phaseDescription, instanceDescription, fieldValue ) ;

        // make sure we have the expected value
        if ( fieldValue != expectedValue )
            {
            throw new TestingException( String.format( "incorrect %s.value",
                                                       instanceDescription ) ) ;
            }

        /*
         * check returned value
         */
        if ( fluentMethod )
            {

            if ( fluentReference == null )
                {
                writeLog( "\tactual: returned: null - must be fluent reference to context instance%n" ) ;
                fail( "missing fluent reference to context instance" ) ;
                }
            else
                {
                // display the actual values
                writeLog( "\tactual: returned: %scorrect instance reference%n",
                          ( testInstance == fluentReference
                              ? ""
                              : "in" ) ) ;

                // expect reference to context instance
                if ( testInstance != fluentReference )
                    {
                    throw new TestingException( "fluent return reference" ) ;
                    }

                }

            }

        }    // end verifyState()

    }	// end class MyXxxxDMRTests