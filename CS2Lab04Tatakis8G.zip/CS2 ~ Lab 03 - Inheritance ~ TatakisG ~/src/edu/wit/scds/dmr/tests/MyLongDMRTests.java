/* @formatter:off
 *
 * Dave Rosenberg
 * Comp 1050 - Computer Science II
 * Lab: Inheritance
 * Spring, 2023
 *
 * Usage restrictions:
 *
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 *
 * Further, you may not post (including in a public repository such as on github)
 * nor otherwise share this code with anyone other than current students in my
 * sections of this course. Violation of these usage restrictions will be considered
 * a violation of the Wentworth Institute of Technology Academic Honesty Policy.
 *
 * Do not remove this notice.
 *
 * @formatter:on
 */


package edu.wit.scds.dmr.tests ;


import org.junit.jupiter.api.DisplayName ;

/**
 * JUnit tests for the Inheritance classes. All methods are tested.
 *
 * @author David M Rosenberg
 *
 * @version 1.0.0 2021-04-18 initial implementation based on TimeDMRTests
 * @version 1.1.0 2021-04-24 fix start test messages for increment and decrement
 * @version 1.2.0 2021-05-03 fix incorrect cast returned values via invoke() to (long) instead of
 *     (Long) - caused some methods that were supposed to return long but were void to appear to
 *     return the value 1 rather than throw an exception
 * @version 2.0.0 2021-08-04
 *     <ul>
 *     <li>restructure to use current testing framework
 *     <li>restructure to support significant evolution of assignment
 *     </ul>
 * @version 2.1.0 2021-08-06 fill in some missing pieces
 * @version 3.0.0 2021-08-08 restructure - move all common functionality to shared superclass
 * @version 3.1.0 2022-04-23 finish cleanup for restructuring
 */
@DisplayName( "MyLong" )
class MyLongDMRTests extends MyXxxxDMRTestingBase
    {

    /**
     * no-arg constructor
     *
     * @throws Throwable
     *     anything thrown during initialization
     */
    protected MyLongDMRTests() throws Throwable
        {
        super( "Long" ) ;

        }   // end no-arg constructor

    /*
     * All test driver methods are in MyXxxxDMRTestingBase
     */

    }	// end class MyLongDMRTests