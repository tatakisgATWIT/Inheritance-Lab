
package edu.wit.scds.cs2.lab03 ;

/**
 * @author George Tatakis
 *
 * @version 1.0.0 2023-03-21 Initial implementation
 * @version 1.0.1 2023-03-26 Added comments
 * @version 1.0.2 2023-03-28 Implemented tests
 */
// MyLong Class
public class MyLong
    {

// Declaring a protected data field named value of type long.
    protected long value ;
    // Declare LOWER_LIMIT
    public static long LOWER_LIMIT = Long.MIN_VALUE ;
    // Declare UPPER_LIMIT
    public static long UPPER_LIMIT = Long.MAX_VALUE ;

    // public MyLong(long value) {
    // this.value = value;
    // constructor that takes initialValue
    public MyLong( long initialValue )
        {
        this() ;
        setValue( initialValue ) ;

        }


// Constructor that takes MyLong object.
    public MyLong( MyLong initialValue )
        {
        this() ;
        setValue( initialValue ) ;

        }


// IsInRange takes a long value and tests if the the value is in range and returns
// true if so.
    @SuppressWarnings( "static-method" )
    protected boolean isInRange( long testValue )
        {

        return true ;

        }


// ToInRange returns the test value.
    @SuppressWarnings( "static-method" )
    protected long toInRange( long testValue )
        {

        return testValue ;

        }


    // Sets value to 0.
    public MyLong()
        {
        this.value = 0 ;

        }


// Returns a value into a string that puts it into the correct format
    @Override
    public String toString()
        {

        return String.format( "%,d", this.value ) ;

        }


// Returns the value.
    public long getValue()
        {
        return this.value ;

        }


// Method tests to see if in range then sets this value to newValue. If not in range
// throws exception saying value is out of range.
    public MyLong setValue( long newValue )
        {
        if ( isInRange( newValue ) )
            {
            this.value = newValue ;
            return this ;

            }

        else
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        }


// setValue tests to see if newValue is null if so setting the newValue to value
    public MyLong setValue( MyLong newValue )
        {

        if ( newValue != null )
            {
            setValue( newValue.value ) ;

            }

        return this ;

        }


// Method tests to find out if testValue is in range. If so it is sets this value to
// testValue. If not throws exception that states value is out of range.
    public boolean equals( long testValue )
        {
        if ( !isInRange( testValue ) )
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        return this.value == testValue ;

        }


// Method checks if Object is equal to MyLong object. if so it calls the equals
// method with the other MyLong Object. Otherwise returns false.
    @Override
    public boolean equals( Object otherObject )
        {
        if ( otherObject instanceof MyLong otherLong )
            {
            return this.equals( otherLong.getValue() ) ;

            }

        return false ;

        }


// Checks to see if value is zero.
    public boolean isZero()
        {
        return this.value == 0 ;

        }


// Checks to see if value is even.
    public boolean isEven()
        {
        return ( this.value % 2 ) == 0 ;

        }


// Checks to see if value is odd.
    public boolean isOdd()
        {
        return !isEven() ;

        }


// Method checks if addend is in range. If not throws IllegalArgumentException. If in
// range adds value to addend. Then puts value through to toInRange method and sets
// it to this.value.
    public MyLong add( long addend )
        {
        if ( !isInRange( addend ) )
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        this.value += addend ;

        this.value = toInRange( this.value ) ;
        return this ;

        }


    // Method checks if subtrahend is in range. If not throws
    // IllegalArgumentException. If in range subtracts subtrahend from value. Then
    // puts value through to toInRange method and sets it to this.value.
    public MyLong subtract( long subtrahend )
        {
        if ( !isInRange( subtrahend ) )
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        this.value -= subtrahend ;
        this.value = toInRange( this.value ) ;
        return this ;

        }


    // Method checks if multiplier is in range. If not throws
    // IllegalArgumentException. If in range value is multiplied by multiplier. Then
    // puts value through to toInRange method and sets it to this.value.
    public MyLong multiply( long multiplier )
        {
        if ( !isInRange( multiplier ) )
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        this.value *= multiplier ;
        this.value = toInRange( this.value ) ;
        return this ;

        }


    // Method checks if divisor is in range and not zero. If not throws
    // IllegalArgumentException. If in range value is divided by divisor. Then puts
    // value through to toInRange method and sets it to this.value.
    public MyLong divide( long divisor )
        {
        if ( divisor == 0 )
            {
            throw new IllegalArgumentException( "divisor is 0" ) ;

            }

        if ( !isInRange( divisor ) )
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        this.value /= divisor ;
        this.value = toInRange( this.value ) ;
        return this ;

        }
    // Method checks if divisor is in range and not zero. If not throws
    // IllegalArgumentException. If in range value is divided by divisor.
    // Then puts value through to toInRange method and sets it this.value.


    public MyLong remainder( long divisor )
        {
        if ( divisor == 0 )
            {
            throw new IllegalArgumentException( "divisor is 0" ) ;

            }

        if ( !isInRange( divisor ) )
            {
            throw new IllegalArgumentException( "value is out of range" ) ;

            }

        this.value %= divisor ;
        this.value = toInRange( this.value ) ;
        return this ;

        }


// Adds 1 to the value.
    public MyLong increment()
        {
        return add( 1 ) ;

        }


// Subtracts 1 from the value.
    public MyLong decrement()
        {
        return subtract( 1 ) ;

        }


// Checks to see if the addend is null, if so it runs the add method.
    public MyLong add( MyLong addend )
        {

        if ( addend != null )
            {
            return add( addend.value ) ;

            }

        return this ;

        }


    // Checks to see if the subtrahend is null, if so it runs the subtract method.
    public MyLong subtract( MyLong subtrahend )
        {

        if ( subtrahend != null )
            {
            return subtract( subtrahend.value ) ;

            }

        return this ;

        }


    // Checks to see if the multiplier is null, if so it runs the multiply method.
    public MyLong multiply( MyLong multiplier )
        {

        if ( multiplier != null )
            {
            return multiply( multiplier.value ) ;

            }

        return this ;

        }


    // Checks to see if the divisor is null, if so it runs the divide method.
    public MyLong divide( MyLong divisor ) throws IllegalArgumentException
        {
        if ( divisor != null )
            {
            return divide( divisor.value ) ;

            }

        return this ;

        }


    // Checks to see if the divisor is null, if so it runs the remainder method.
    public MyLong remainder( MyLong divisor ) throws IllegalArgumentException
        {

        if ( divisor != null )
            {
            return remainder( divisor.value ) ;

            }

        return this ;

        }


    public static void main( String[] args )
        {
        MyLong value = new MyLong( 9 ) ;
        value.setValue( 4 ) ;
        System.out.println( "Value: " + value.toString() ) ; // Expected: 4
        System.out.println( "Add 20: " + value.add( 20 ) ) ;// Expected: 24
        System.out.println( "Subtract 20:" + value.subtract( 16 ) ) ; // Expected: 8
        System.out.println( "Multiply 5:" + value.multiply( 5 ) ) ; // Expected: 40
        System.out.println( "Divide 20: " + value.divide( 20 ) ) ; // Expected: 2
        value.setValue( 9 ) ;
        System.out.println( "Value: " + value.toString() ) ; // Expected: 9
        System.out.println( "remainder: " + value.remainder( 2 ) ) ; // Expected: 1
        System.out.println( "Increment: " + value.increment() ) ; // Expected: 2
        System.out.println( "Decrement: " + value.decrement() ) ; // Expected: 1
        System.out.println( "Is Even: " + value.isEven() ) ; // Expected: False
        System.out.println( "Is Odd: " + value.isOdd() ) ; // Expected: True
        System.out.println( "Is Zero: " + value.isZero() ) ; // Expected: False

        }

    }
// end class MyLong