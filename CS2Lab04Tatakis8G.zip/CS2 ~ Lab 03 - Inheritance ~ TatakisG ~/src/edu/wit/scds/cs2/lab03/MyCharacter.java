
package edu.wit.scds.cs2.lab03 ;

/**
 * @author George Tatakis
 *
 * @version 1.0.0 2023-03-25 Initial implementation
 * @version 1.1.0 2023-03-28 Finished test and comments
 */
// Extends MyLong to MyCharacter.
public class MyCharacter extends MyLong
    {

    // Defines minimum value Character can hold.
    @SuppressWarnings( "hiding" )
    public final static long LOWER_LIMIT = Character.MIN_VALUE ;
    @SuppressWarnings( "hiding" )
    // Defines Maximum value Character can hold.
    public final static long UPPER_LIMIT = Character.MAX_VALUE ;

    /**
     *
     */
    // Checks if testValue is in range between the upper and lower limit.
    // Will return upper or lower limit if it is out of range.
    // Else will return the test value back.
    @Override
    protected boolean isInRange( long testValue )
        {
        return ( testValue >= LOWER_LIMIT ) && ( testValue <= UPPER_LIMIT ) ;

        }


    @Override
    protected long toInRange( long testValue )
        {
        if ( testValue < LOWER_LIMIT )
            {
            return LOWER_LIMIT ;

            }
        else if ( testValue > UPPER_LIMIT )
            {
            return UPPER_LIMIT ;

            }
        else
            {
            return testValue ;

            }

        }


    // Calls constructors from MyLong class.
    public MyCharacter()
        {
        super() ;

        // TODO Auto-generated constructor stub
        }


    // Calls constructor with the long initialValue parameter.
    public MyCharacter( long initialValue )
        {

        super( initialValue ) ;

        }


// Calls constructor with the MyLong initialValue parameter.
    public MyCharacter( MyLong initialValue )
        {
        super( initialValue ) ;

        }


    /**
     *
     */

    /**
     * @param args
     */
    public static void main( String[] args )
        {
        // TODO Auto-generated method stub
        MyCharacter myCharacter = new MyCharacter( 42 ) ;
        System.out.println( "Character: " + myCharacter.getValue() ) ; // Expected:
                                                                       // 42
        System.out.println( "Subtract 20:" + myCharacter.subtract( 16 ) ) ;// Expected:
                                                                           // 26
        System.out.println( "Multiply 5:" + myCharacter.multiply( 5 ) ) ;// Expected:
                                                                         // 127
        System.out.println( "Divide 20: " + myCharacter.divide( 20 ) ) ;// Expected:
                                                                        // 6
        long testInRange = Character.MIN_VALUE + 1 ;
        System.out.println( "Above minimum:" + myCharacter.isInRange( testInRange ) ) ; // Expected:
                                                                                       // true

        }

    }

// end class MyCharacter