
package edu.wit.scds.cs2.lab03 ;

/**
 * @author George Tatakis
 *
 * @version 1.0.0 2023-03-25 Initial implementation
 * @version 1.1.0 2023-03-28 Finished test and comments
 */
// Extends MyLong to MyInteger.
public class MyInteger extends MyLong
    {

    // Defines minimum value Integer can hold.
    @SuppressWarnings( "hiding" )
    public final static long LOWER_LIMIT = Integer.MIN_VALUE ;
    // Defines Maximum value Integer can hold.
    @SuppressWarnings( "hiding" )
    public final static long UPPER_LIMIT = Integer.MAX_VALUE ;

    /**
     *
     */
    // Checks if testValue is in range between the upper and lower limit.
    // Will return upper or lower limit if it is out of range.
    // Else will return the test value back.
    @Override
    protected boolean isInRange( long testValue )
        {
        return ( testValue >= LOWER_LIMIT ) && ( testValue <= UPPER_LIMIT ) ;

        }


    @Override
    protected long toInRange( long testValue )
        {
        if ( testValue < LOWER_LIMIT )
            {
            return LOWER_LIMIT ;

            }
        else if ( testValue > UPPER_LIMIT )
            {
            return UPPER_LIMIT ;

            }
        else
            {
            return testValue ;

            }

        }


    // Calls Constructors from MyLong class.
    public MyInteger()
        {
        super() ;

        // TODO Auto-generated constructor stub
        }


    // Calls constructor with the long initialValue parameter.
    public MyInteger( long initialValue )
        {

        super( initialValue ) ;

        }


// Calls constructor with the MyLong initialValue parameter.
    public MyInteger( MyLong initialValue )
        {
        super( initialValue ) ;

        }


    /**
     * @param args
     */
    public static void main( String[] args )
        {
        // TODO Auto-generated method stub
        MyInteger myInteger = new MyInteger( 42 ) ;
        System.out.println( "Byte: " + myInteger.getValue() ) ;// Expected: 42
        System.out.println( "Subtract 20:" + myInteger.subtract( 16 ) ) ;// Expected:
                                                                         // 26
        System.out.println( "Multiply 5:" + myInteger.multiply( 5 ) ) ; // Expected:
                                                                        // 127
        System.out.println( "Divide 20: " + myInteger.divide( 2 ) ) ;// Expected: 6
        long aboveRange = Integer.MAX_VALUE + 1 ;
        System.out.println( "Above Max:" + myInteger.isInRange( aboveRange ) ) ; // Expected:
                                                                                 // false

        }

    }
// end class MyInteger